/* @ds-bundle: {"format":4,"namespace":"DrupalDesignSystem_e0f3ad","components":[{"name":"DropWindow","sourcePath":"components/brand/DropWindow.jsx"},{"name":"GuiBlock","sourcePath":"components/brand/GuiBlock.jsx"},{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"PatternPanel","sourcePath":"components/brand/PatternPanel.jsx"},{"name":"StatBlock","sourcePath":"components/brand/StatBlock.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Breadcrumbs","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/brand/DropWindow.jsx":"95d208e16f99","components/brand/GuiBlock.jsx":"be3f53a988fd","components/brand/Logo.jsx":"b9fa37704da3","components/brand/PatternPanel.jsx":"0bec8ad6d760","components/brand/StatBlock.jsx":"44ae5201849c","components/core/Badge.jsx":"54615b8026b2","components/core/Button.jsx":"03ef00942425","components/core/Card.jsx":"fd534ca8fc49","components/core/Icon.jsx":"3133651c45f5","components/core/IconButton.jsx":"8ff737aceb34","components/core/Tag.jsx":"2dbb281f764c","components/feedback/Dialog.jsx":"612d67239dd9","components/feedback/Toast.jsx":"0ccf18b44dfe","components/feedback/Tooltip.jsx":"0f34a7491a32","components/forms/Checkbox.jsx":"e7482c5a382e","components/forms/Input.jsx":"20c1f5aee846","components/forms/Radio.jsx":"550cf5d9df23","components/forms/Select.jsx":"ced1872164f7","components/forms/Switch.jsx":"78fff4da86e8","components/navigation/Breadcrumbs.jsx":"6d2a31e056ac","components/navigation/Tabs.jsx":"8958e38d308f","ui_kits/drupal-cms/Sections.jsx":"2c8a2220dd39","ui_kits/drupal-cms/SiteChrome.jsx":"f878a19b1738","ui_kits/drupal-org/OrgChrome.jsx":"f518cf564e24","ui_kits/drupal-org/OrgScreens.jsx":"df630d2fe74e","ui_kits/drupalcon/EventScreens.jsx":"49eae81c3709"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DrupalDesignSystem_e0f3ad = window.DrupalDesignSystem_e0f3ad || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/DropWindow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* "Drop Window": the drop — or a rectangle cropped out of part of it — used as a mask for
   photography or video. The mask is the official white drop asset, so the silhouette is exact. */
function DropWindow({
  children,
  size = 280,
  basePath = 'assets/png/logos',
  background = 'var(--surface-subtle)',
  style,
  ...rest
}) {
  const url = 'url("' + basePath + '/Drupal-Drop_White.png")';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      width: size,
      height: size,
      background,
      overflow: 'hidden',
      WebkitMaskImage: url,
      maskImage: url,
      WebkitMaskRepeat: 'no-repeat',
      maskRepeat: 'no-repeat',
      WebkitMaskSize: 'contain',
      maskSize: 'contain',
      WebkitMaskPosition: 'center',
      maskPosition: 'center',
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { DropWindow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/DropWindow.jsx", error: String((e && e.message) || e) }); }

// components/brand/GuiBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const FILL = {
  blue: 'var(--drupal-blue)',
  'dark-blue': 'var(--drupal-dark-blue)',
  navy: 'var(--drupal-navy)',
  'light-blue': 'var(--drupal-light-blue)',
  purple: 'var(--drupal-purple)',
  yellow: 'var(--drupal-yellow)',
  red: 'var(--drupal-red)',
  green: 'var(--drupal-green)',
  white: 'var(--drupal-white)'
};
const INK_ON = {
  blue: 'var(--drupal-white)',
  'dark-blue': 'var(--drupal-white)',
  navy: 'var(--drupal-white)',
  'light-blue': 'var(--drupal-navy)',
  purple: 'var(--drupal-navy)',
  yellow: 'var(--drupal-navy)',
  red: 'var(--drupal-white)',
  green: 'var(--drupal-white)',
  white: 'var(--drupal-navy)'
};

/* The brand's GUI Block, built the way the guidelines describe it:
   rounded rectangle -> duplicate shifted diagonally at 45 degrees (offset kept to ~3 line
   widths) -> matching corner radii -> 0-3 unfilled control dots -> 45 degree line shadow.
   Enforced here: never more than 3 colours per block, never a gradient fill. */
function GuiBlock({
  children,
  tone = 'yellow',
  lineColor,
  variant = 'filled',
  size = 320,
  radius,
  dots = 3,
  lineShadow = true,
  lineWidth = 2,
  image,
  style,
  ...rest
}) {
  const fill = FILL[tone] || FILL.yellow;
  const stroke = lineColor ? FILL[lineColor] || lineColor : fill;
  const r = radius ?? Math.round(size * 0.17);
  const filled = variant === 'filled';
  const ink = filled ? INK_ON[tone] || 'var(--drupal-navy)' : stroke;
  const off = lineWidth * 3;
  const dotCount = Math.max(0, Math.min(3, dots));
  const shadow = `repeating-linear-gradient(135deg,${filled ? fill : stroke} 0 ${lineWidth}px,transparent ${lineWidth}px ${lineWidth * 4}px)`;
  const shift = `translate(-${off}px,${off}px)`;
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      position: 'relative',
      width: size,
      height: size,
      ...style
    }
  }), lineShadow && /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      transform: shift,
      borderRadius: r,
      background: shadow
    }
  }), !filled && /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      transform: shift,
      borderRadius: r,
      border: lineWidth + 'px solid ' + stroke
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: r,
      overflow: 'hidden',
      background: filled ? fill : 'var(--surface-page)',
      border: filled ? 'none' : lineWidth + 'px solid ' + stroke,
      display: 'flex',
      flexDirection: 'column'
    }
  }, image && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0
    }
  }, image), dotCount > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      gap: Math.round(size * 0.03),
      padding: Math.round(size * 0.07) + 'px ' + Math.round(size * 0.075) + 'px 0'
    }
  }, Array.from({
    length: dotCount
  }).map((_, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: Math.round(size * 0.044),
      height: Math.round(size * 0.044),
      borderRadius: '50%',
      border: Math.max(2, lineWidth) + 'px solid ' + ink
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: Math.round(size * 0.075),
      font: 'var(--text-h3)',
      color: ink,
      textAlign: 'center'
    }
  }, children)));
}
Object.assign(__ds_scope, { GuiBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/GuiBlock.jsx", error: String((e && e.message) || e) }); }

// components/brand/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const FILES = {
  'drupal-horizontal': n => `Drupal-Logo_Horizontal_${n}.png`,
  'drupal-vertical': n => `Drupal-Logo_Vertical_${n}.png`,
  'drop': n => `Drupal-Drop_${n}.png`,
  'cms-horizontal': n => `Drupal-Product-Logo-CMS-Horizontal-Wordmark-${n}.png`,
  'cms-vertical': n => `Drupal-Product-Logo-CMS-Vertical-Wordmark-${n}.png`,
  'cms-mark': n => `Drupal-Product-Logo-CMS-Horizontal-No-Wordmark-${n}.png`
};
const COLORS = {
  blue: 'Blue',
  navy: 'Navy',
  white: 'White',
  black: 'Black'
};
function Logo({
  variant = 'drupal-horizontal',
  color = 'blue',
  height = 40,
  basePath = 'assets/png/logos',
  alt,
  style,
  ...rest
}) {
  const key = FILES[variant] ? variant : 'drupal-horizontal';
  let name = COLORS[color] || 'Blue';
  if (key.startsWith('cms') && (name === 'Navy' || name === 'Black')) name = 'Blue'; // CMS product logo ships blue + white only
  const src = `${basePath}/${FILES[key](name)}`;
  return /*#__PURE__*/React.createElement("img", _extends({
    src: src,
    alt: alt ?? (key.startsWith('cms') ? 'Drupal CMS' : 'Drupal')
  }, rest, {
    style: {
      height,
      width: 'auto',
      display: 'block',
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/brand/PatternPanel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const PATTERNS = {
  'blue-dense': 'Drupal_Dynamic-Patterns-01.png',
  'blue-multiply': 'Drupal_Dynamic-Patterns-02.png',
  'tint-lines': 'Drupal_Dynamic-Patterns-03.png',
  'grey-soft': 'Drupal_Dynamic-Patterns-04.png',
  'lavender-mix': 'Drupal_Dynamic-Patterns-05.png',
  'grey-light': 'Drupal_Dynamic-Patterns-06.png'
};
function PatternPanel({
  children,
  pattern = 'blue-dense',
  background = 'var(--surface-page)',
  size = 'cover',
  position = 'center',
  opacity = 1,
  basePath = 'assets/png/patterns',
  style,
  ...rest
}) {
  const file = PATTERNS[pattern] || PATTERNS['blue-dense'];
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      position: 'relative',
      isolation: 'isolate',
      background,
      overflow: 'hidden',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: -1,
      opacity,
      backgroundImage: `url("${basePath}/${file}")`,
      backgroundSize: size,
      backgroundPosition: position,
      backgroundRepeat: 'no-repeat'
    }
  }), children);
}
Object.assign(__ds_scope, { PatternPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/PatternPanel.jsx", error: String((e && e.message) || e) }); }

// components/brand/StatBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatBlock({
  value,
  label,
  tone = 'navy',
  align = 'left',
  style,
  ...rest
}) {
  const color = tone === 'inverse' ? 'var(--drupal-white)' : tone === 'blue' ? 'var(--drupal-blue)' : 'var(--drupal-navy)';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      textAlign: align,
      alignItems: align === 'center' ? 'center' : 'flex-start',
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-display)',
      color,
      letterSpacing: 'var(--tracking-tight)'
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-md)',
      color: tone === 'inverse' ? 'rgba(255,255,255,.82)' : 'var(--text-body)',
      maxWidth: '22ch'
    }
  }, label));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  brand: {
    background: 'var(--surface-brand)',
    color: 'var(--text-on-brand)'
  },
  navy: {
    background: 'var(--surface-inverse)',
    color: 'var(--text-inverse)'
  },
  yellow: {
    background: 'var(--yellow)',
    color: 'var(--drupal-navy)'
  },
  coral: {
    background: 'var(--coral)',
    color: 'var(--drupal-white)'
  },
  lavender: {
    background: 'var(--lavender)',
    color: 'var(--drupal-navy)'
  },
  tint: {
    background: 'var(--blue-tint)',
    color: 'var(--drupal-navy)'
  },
  neutral: {
    background: 'var(--neutral-100)',
    color: 'var(--text-body)'
  }
};
function Badge({
  children,
  tone = 'brand',
  uppercase = true,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.brand;
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '4px 12px',
      borderRadius: 'var(--radius-pill)',
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: uppercase ? 'uppercase' : 'none',
      ...t,
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CDN = 'https://unpkg.com/lucide-static@0.544.0/icons/';

/* Lucide is a documented SUBSTITUTION: the Drupal brand portal ships no icon set.
   Rendered as a CSS mask so the glyph inherits currentColor. */
function Icon({
  name = 'circle',
  size = 20,
  color = 'currentColor',
  strokeWidth,
  style,
  ...rest
}) {
  const url = `url("${CDN}${name}.svg")`;
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true"
  }, rest, {
    style: {
      display: 'inline-block',
      flex: '0 0 auto',
      width: size,
      height: size,
      background: color,
      WebkitMaskImage: url,
      maskImage: url,
      WebkitMaskRepeat: 'no-repeat',
      maskRepeat: 'no-repeat',
      WebkitMaskSize: 'contain',
      maskSize: 'contain',
      WebkitMaskPosition: 'center',
      maskPosition: 'center',
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    padding: '8px 16px',
    fontSize: 'var(--size-2xs)',
    gap: 6,
    icon: 16,
    minHeight: 36
  },
  md: {
    padding: '12px 24px',
    fontSize: 'var(--size-xs)',
    gap: 8,
    icon: 20,
    minHeight: 48
  },
  lg: {
    padding: '16px 32px',
    fontSize: 'var(--size-sm)',
    gap: 10,
    icon: 22,
    minHeight: 56
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--action-primary)',
    color: 'var(--text-on-brand)',
    border: '2px solid var(--action-primary)'
  },
  secondary: {
    background: 'var(--action-secondary)',
    color: 'var(--text-inverse)',
    border: '2px solid var(--action-secondary)'
  },
  outline: {
    background: 'transparent',
    color: 'var(--drupal-navy)',
    border: '2px solid var(--drupal-navy)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--drupal-blue)',
    border: '2px solid transparent'
  },
  inverse: {
    background: 'var(--drupal-white)',
    color: 'var(--drupal-navy)',
    border: '2px solid var(--drupal-white)'
  }
};
const HOVER = {
  primary: {
    background: 'var(--action-primary-hover)',
    borderColor: 'var(--action-primary-hover)'
  },
  secondary: {
    background: 'var(--action-secondary-hover)',
    borderColor: 'var(--action-secondary-hover)'
  },
  outline: {
    background: 'var(--drupal-navy)',
    color: 'var(--text-inverse)'
  },
  ghost: {
    background: 'var(--blue-tint)'
  },
  inverse: {
    background: 'var(--blue-tint)',
    borderColor: 'var(--blue-tint)'
  }
};
function Button({
  children,
  variant = 'primary',
  size = 'md',
  iconLeft,
  iconRight,
  fullWidth = false,
  disabled = false,
  as = 'button',
  href,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md,
    v = VARIANTS[variant] || VARIANTS.primary;
  const Tag = href ? 'a' : as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    disabled: Tag === 'button' ? disabled : undefined,
    "aria-disabled": disabled || undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : 'auto',
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      padding: s.padding,
      minHeight: s.minHeight,
      borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-body)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: s.fontSize,
      lineHeight: 1,
      textDecoration: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .4 : 1,
      transition: 'var(--transition-interactive)',
      transform: press && !disabled ? 'translateY(1px)' : 'none',
      ...v,
      ...(hover && !disabled ? HOVER[variant] : null),
      ...style
    }
  }, rest), iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon
  }), /*#__PURE__*/React.createElement("span", null, children), iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  children,
  title,
  eyebrow,
  body,
  media,
  href,
  linkLabel,
  tone = 'light',
  padding = 24,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const dark = tone === 'navy';
  const tint = tone === 'tint';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      borderRadius: 'var(--radius-lg)',
      background: dark ? 'var(--surface-inverse)' : tint ? 'var(--surface-accent-tint)' : 'var(--surface-card)',
      border: `1px solid ${dark ? 'var(--border-inverse)' : tint ? 'transparent' : 'var(--border-subtle)'}`,
      boxShadow: href && hover ? 'var(--shadow-md)' : 'var(--shadow-sm)',
      transform: href && hover ? 'translateY(-2px)' : 'none',
      transition: 'box-shadow var(--duration-base) var(--ease-standard),transform var(--duration-base) var(--ease-standard)',
      ...style
    }
  }), media && /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '16/9',
      overflow: 'hidden',
      background: 'var(--neutral-100)'
    }
  }, media), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      padding
    }
  }, eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: dark ? 'var(--blue-pale)' : 'var(--drupal-blue)'
    }
  }, eyebrow), title && /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h4)',
      color: dark ? 'var(--text-inverse)' : 'var(--text-strong)'
    }
  }, title), body && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: 'var(--text-body-md)',
      color: dark ? 'rgba(255,255,255,.82)' : 'var(--text-body)'
    }
  }, body), children, href && /*#__PURE__*/React.createElement("a", {
    href: href,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      marginTop: 8,
      font: 'var(--text-label)',
      color: dark ? 'var(--drupal-white)' : 'var(--text-link)',
      textDecoration: hover ? 'underline' : 'none'
    }
  }, linkLabel || 'Learn more', /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-right",
    size: 16
  }))));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    box: 36,
    icon: 18
  },
  md: {
    box: 44,
    icon: 20
  },
  lg: {
    box: 52,
    icon: 24
  }
};
function IconButton({
  icon = 'x',
  label,
  size = 'md',
  variant = 'ghost',
  disabled = false,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const base = variant === 'solid' ? {
    background: 'var(--action-primary)',
    color: 'var(--text-on-brand)',
    border: '2px solid var(--action-primary)'
  } : variant === 'outline' ? {
    background: 'transparent',
    color: 'var(--drupal-navy)',
    border: '2px solid var(--border-strong)'
  } : {
    background: 'transparent',
    color: 'var(--drupal-navy)',
    border: '2px solid transparent'
  };
  const hov = variant === 'solid' ? {
    background: 'var(--action-primary-hover)',
    borderColor: 'var(--action-primary-hover)'
  } : {
    background: 'var(--surface-subtle)'
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: s.box,
      height: s.box,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-pill)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .4 : 1,
      transition: 'var(--transition-interactive)',
      ...base,
      ...(hover && !disabled ? hov : null),
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: s.icon
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  children,
  selected = false,
  onRemove,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: onRemove ? '6px 8px 6px 14px' : '6px 14px',
      borderRadius: 'var(--radius-pill)',
      font: 'var(--text-body-sm)',
      cursor: rest.onClick ? 'pointer' : 'default',
      background: selected ? 'var(--drupal-navy)' : hover && rest.onClick ? 'var(--blue-tint)' : 'var(--surface-page)',
      color: selected ? 'var(--text-inverse)' : 'var(--drupal-navy)',
      border: `1px solid ${selected ? 'var(--drupal-navy)' : 'var(--border-strong)'}`,
      transition: 'var(--transition-interactive)',
      ...style
    }
  }), children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove",
    onClick: onRemove,
    style: {
      display: 'inline-flex',
      border: 0,
      background: 'transparent',
      padding: 2,
      cursor: 'pointer',
      color: 'inherit'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 14
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Dialog({
  open = false,
  title,
  description,
  children,
  footer,
  onClose,
  width = 560,
  style,
  ...rest
}) {
  React.useEffect(() => {
    if (!open) return;
    const k = e => {
      if (e.key === 'Escape' && onClose) onClose();
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 60,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24,
      background: 'rgba(18,40,95,.48)',
      backdropFilter: 'blur(3px)'
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", _extends({
    role: "dialog",
    "aria-modal": "true",
    "aria-label": title,
    onClick: e => e.stopPropagation()
  }, rest, {
    style: {
      width: '100%',
      maxWidth: width,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-lg)',
      padding: 32,
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, title && /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h3)',
      color: 'var(--text-strong)',
      margin: 0
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: 'var(--text-body-md)',
      color: 'var(--text-body)'
    }
  }, description)), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    onClick: onClose
  })), children, footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'flex-end',
      marginTop: 8
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  info: {
    icon: 'info',
    accent: 'var(--status-info)'
  },
  success: {
    icon: 'check-circle',
    accent: 'var(--status-success)'
  },
  warning: {
    icon: 'alert-triangle',
    accent: 'var(--status-warning)'
  },
  danger: {
    icon: 'alert-circle',
    accent: 'var(--status-danger)'
  }
};
function Toast({
  title,
  message,
  tone = 'info',
  onClose,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status"
  }, rest, {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start',
      minWidth: 320,
      maxWidth: 440,
      padding: '16px 16px 16px 18px',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--border-subtle)',
      borderLeft: `4px solid ${t.accent}`,
      boxShadow: 'var(--shadow-md)',
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 20,
    color: t.accent,
    style: {
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      flex: 1
    }
  }, title && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-label)',
      color: 'var(--text-strong)'
    }
  }, title), message && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-body)'
    }
  }, message)), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Dismiss",
    size: "sm",
    onClick: onClose
  }));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tooltip({
  label,
  children,
  placement = 'top',
  style,
  ...rest
}) {
  const [show, setShow] = React.useState(false);
  const pos = placement === 'bottom' ? {
    top: 'calc(100% + 8px)',
    left: '50%',
    transform: 'translateX(-50%)'
  } : {
    bottom: 'calc(100% + 8px)',
    left: '50%',
    transform: 'translateX(-50%)'
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, rest), children, show && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      zIndex: 50,
      whiteSpace: 'nowrap',
      ...pos,
      background: 'var(--drupal-navy)',
      color: 'var(--text-inverse)',
      font: 'var(--text-body-sm)',
      padding: '6px 10px',
      borderRadius: 'var(--radius-xs)',
      boxShadow: 'var(--shadow-md)'
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  description,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  id,
  style,
  ...rest
}) {
  const uid = id || React.useId();
  const [inner, setInner] = React.useState(!!defaultChecked);
  const on = checked !== undefined ? checked : inner;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    type: "checkbox",
    checked: on,
    disabled: disabled,
    onChange: e => {
      if (checked === undefined) setInner(e.target.checked);
      onChange && onChange(e);
    },
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flex: '0 0 auto',
      width: 22,
      height: 22,
      marginTop: 1,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-xs)',
      background: on ? 'var(--action-primary)' : 'var(--surface-page)',
      border: `2px solid ${on ? 'var(--action-primary)' : 'var(--border-strong)'}`,
      transition: 'var(--transition-interactive)'
    }
  }, on && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 14,
    color: "var(--drupal-white)"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-strong)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  iconLeft,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      width: '100%'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      font: 'var(--text-label)',
      color: 'var(--text-strong)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 14,
      display: 'flex',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: 18
  })), /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    "aria-invalid": !!error,
    "aria-describedby": hint || error ? uid + '-d' : undefined,
    style: {
      width: '100%',
      minHeight: 48,
      padding: iconLeft ? '12px 16px 12px 42px' : '12px 16px',
      font: 'var(--text-body-md)',
      color: 'var(--text-strong)',
      background: 'var(--surface-page)',
      borderRadius: 'var(--radius-sm)',
      border: `1px solid ${error ? 'var(--status-danger)' : focus ? 'var(--border-brand)' : 'var(--border-strong)'}`,
      boxShadow: focus ? 'var(--shadow-focus)' : 'none',
      outline: 'none',
      transition: 'border-color var(--duration-fast) var(--ease-standard),box-shadow var(--duration-fast) var(--ease-standard)',
      ...style
    }
  }, rest))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    id: uid + '-d',
    style: {
      font: 'var(--text-body-sm)',
      color: error ? 'var(--status-danger)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  label,
  description,
  name,
  value,
  checked,
  onChange,
  disabled = false,
  id,
  style,
  ...rest
}) {
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flex: '0 0 auto',
      width: 22,
      height: 22,
      marginTop: 1,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--surface-page)',
      border: `2px solid ${checked ? 'var(--action-primary)' : 'var(--border-strong)'}`,
      transition: 'var(--transition-interactive)'
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 11,
      height: 11,
      borderRadius: '50%',
      background: 'var(--action-primary)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-strong)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, description)));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  hint,
  error,
  options = [],
  placeholder,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      width: '100%'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      font: 'var(--text-label)',
      color: 'var(--text-strong)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: uid,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      minHeight: 48,
      padding: '12px 44px 12px 16px',
      appearance: 'none',
      font: 'var(--text-body-md)',
      color: 'var(--text-strong)',
      background: 'var(--surface-page)',
      borderRadius: 'var(--radius-sm)',
      border: `1px solid ${error ? 'var(--status-danger)' : focus ? 'var(--border-brand)' : 'var(--border-strong)'}`,
      boxShadow: focus ? 'var(--shadow-focus)' : 'none',
      outline: 'none',
      cursor: 'pointer',
      ...style
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), options.map(o => {
    const v = typeof o === 'string' ? o : o.value,
      l = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 16,
      pointerEvents: 'none',
      display: 'flex',
      color: 'var(--drupal-navy)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 18
  }))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: error ? 'var(--status-danger)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  id,
  style,
  ...rest
}) {
  const uid = id || React.useId();
  const [inner, setInner] = React.useState(!!defaultChecked);
  const on = checked !== undefined ? checked : inner;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      display: 'inline-flex',
      gap: 12,
      alignItems: 'center',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    type: "checkbox",
    role: "switch",
    checked: on,
    disabled: disabled,
    onChange: e => {
      if (checked === undefined) setInner(e.target.checked);
      onChange && onChange(e);
    },
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 48,
      height: 28,
      borderRadius: 'var(--radius-pill)',
      padding: 3,
      display: 'flex',
      background: on ? 'var(--action-primary)' : 'var(--neutral-300)',
      transition: 'background-color var(--duration-base) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 22,
      borderRadius: '50%',
      background: 'var(--drupal-white)',
      transform: on ? 'translateX(20px)' : 'translateX(0)',
      transition: 'transform var(--duration-base) var(--ease-standard)',
      boxShadow: 'var(--shadow-sm)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-strong)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumbs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Breadcrumbs({
  items = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    "aria-label": "Breadcrumb"
  }, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      flexWrap: 'wrap',
      gap: 8,
      ...style
    }
  }), items.map((it, i) => {
    const label = it.label || it,
      href = it.href;
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: label
    }, href && !last ? /*#__PURE__*/React.createElement("a", {
      href: href,
      style: {
        font: 'var(--text-body-sm)',
        color: 'var(--text-link)',
        textDecoration: 'none'
      }
    }, label) : /*#__PURE__*/React.createElement("span", {
      "aria-current": last ? 'page' : undefined,
      style: {
        font: 'var(--text-body-sm)',
        color: last ? 'var(--text-strong)' : 'var(--text-muted)'
      }
    }, label), !last && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "chevron-right",
      size: 14,
      color: "var(--neutral-400)"
    }));
  }));
}
Object.assign(__ds_scope, { Breadcrumbs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  items = [],
  value,
  defaultValue,
  onChange,
  variant = 'underline',
  style,
  ...rest
}) {
  const [inner, setInner] = React.useState(defaultValue ?? (items[0] && (items[0].value || items[0])));
  const active = value !== undefined ? value : inner;
  const pick = v => {
    if (value === undefined) setInner(v);
    onChange && onChange(v);
  };
  const pill = variant === 'pill';
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist"
  }, rest, {
    style: {
      display: 'flex',
      gap: pill ? 8 : 28,
      borderBottom: pill ? 'none' : '1px solid var(--border-subtle)',
      ...style
    }
  }), items.map(it => {
    const v = it.value || it,
      l = it.label || it,
      on = v === active;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      role: "tab",
      "aria-selected": on,
      onClick: () => pick(v),
      style: {
        border: 0,
        background: pill ? on ? 'var(--drupal-navy)' : 'var(--surface-subtle)' : 'transparent',
        color: pill ? on ? 'var(--text-inverse)' : 'var(--drupal-navy)' : on ? 'var(--drupal-navy)' : 'var(--text-muted)',
        font: 'var(--text-label)',
        padding: pill ? '10px 20px' : '0 0 14px',
        cursor: 'pointer',
        borderRadius: pill ? 'var(--radius-pill)' : 0,
        boxShadow: !pill && on ? 'inset 0 -3px 0 0 var(--drupal-blue)' : 'none',
        transition: 'var(--transition-interactive)'
      }
    }, l);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/drupal-cms/Sections.jsx
try { (() => {
const DS = window.DrupalDesignSystem_e0f3ad;
const A = '../../assets';
function Hero({
  onTrial
}) {
  const {
    Button,
    Badge,
    GuiBlock,
    PatternPanel,
    Logo
  } = DS;
  return /*#__PURE__*/React.createElement(PatternPanel, {
    pattern: "tint-lines",
    background: "var(--surface-page)",
    basePath: A + '/png/patterns',
    size: "cover",
    opacity: .5
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: '1.05fr .95fr',
      gap: 56,
      alignItems: 'center',
      padding: '80px 32px 88px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "cms-horizontal",
    color: "blue",
    height: 44,
    basePath: A + '/png/logos'
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-display)',
      color: 'var(--drupal-navy)',
      letterSpacing: 'var(--tracking-tight)',
      margin: 0,
      maxWidth: '18ch'
    }
  }, "Your Launchpad for Limitless Marketing Possibilities"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      color: 'var(--text-body)',
      maxWidth: '46ch',
      margin: 0
    }
  }, "Drupal CMS puts the power of Drupal into the hands of marketers, designers and content creators."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    iconRight: "arrow-right",
    onClick: onTrial
  }, "Try Drupal CMS 2.0"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "outline",
    href: "#download"
  }, "Download & Build")), /*#__PURE__*/React.createElement(Badge, {
    tone: "yellow"
  }, "Free and open source, always")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(GuiBlock, {
    tone: "yellow",
    size: 380,
    radius: 64
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-h3)',
      display: 'block',
      maxWidth: '14ch'
    }
  }, "Drupal Canvas visual page building")))));
}
function ReleaseBand() {
  const {
    Card,
    Button,
    Badge
  } = DS;
  const points = ['Visual page building with Drupal Canvas', 'Site templates install in under 3 minutes', 'One-click marketing integrations', 'Optional AI tools with governance', '26-33% faster performance'];
  const {
    Icon
  } = DS;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--drupal-navy)',
      color: 'var(--text-inverse)',
      padding: 'var(--space-20) 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 56,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "yellow"
  }, "New release"), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h1)',
      color: 'var(--drupal-white)',
      margin: 0
    }
  }, "Drupal CMS 2.0 is Here"), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      padding: 0,
      margin: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, points.map(p => /*#__PURE__*/React.createElement("li", {
    key: p,
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start',
      font: 'var(--text-body-md)',
      color: 'rgba(255,255,255,.88)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 20,
    color: "var(--yellow)",
    style: {
      marginTop: 3
    }
  }), p))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap',
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "inverse",
    iconRight: "arrow-right"
  }, "Try it now"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    style: {
      color: 'var(--blue-pale)'
    }
  }, "Read more about 2.0"))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      border: '1px solid var(--border-inverse)',
      background: 'var(--navy-alt)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      padding: '14px 16px',
      borderBottom: '1px solid var(--border-inverse)'
    }
  }, ['var(--coral)', 'var(--yellow)', 'var(--drupal-blue)'].map(c => /*#__PURE__*/React.createElement("span", {
    key: c,
    style: {
      width: 11,
      height: 11,
      borderRadius: '50%',
      background: c
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 300,
      background: 'var(--gradient-navy-blue)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      font: 'var(--text-body-sm)',
      color: 'rgba(255,255,255,.8)',
      textAlign: 'center',
      padding: 24
    }
  }, "Product screenshot slot \u2014 drop a Drupal Canvas capture here"))));
}
function WhyGrid() {
  const {
    Card
  } = DS;
  const items = [['Lightning fast launch', 'Smart defaults and pre-built recipes get you from idea to live site faster than ever.', 'zap'], ['Built for marketers', 'Intuitive drag-and-drop tools, visual page building, and marketer-friendly interfaces designed with your workflow in mind.', 'wand-2'], ['Build without limits', 'From startup to enterprise, Drupal CMS grows with you. Handle millions of visitors, thousands of pages, and complex integrations effortlessly.', 'trending-up'], ['Powerful & open', 'As an accessible, secure open source platform, it checks all the boxes for your IT team. Your content, your data, your choice.', 'shield-check']];
  const {
    Icon
  } = DS;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: 'var(--section-y) 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h1)',
      margin: '0 0 40px',
      maxWidth: '24ch'
    }
  }, "Why Ambitious Marketers Choose Drupal CMS"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 24
    }
  }, items.map(([t, b, ic]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    tone: "tint",
    padding: 28
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 32,
    color: "var(--drupal-blue)"
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h4)',
      margin: '12px 0 6px'
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      margin: 0
    }
  }, b))))));
}
function FeatureTabs() {
  const {
    Tabs,
    Icon,
    Button
  } = DS;
  const features = {
    'Quick setup': ['Quick setup, easy admin', 'Launch your site quickly with tools designed for marketing teams, then manage it effortlessly with intuitive admin tools and automated processes—no technical expertise required.', 'settings'],
    'Marketing': ['Marketing launchpad', 'Ready-to-use content types and intelligent workflows help you build engaging digital experiences faster.', 'megaphone'],
    'AI': ['AI-powered building', 'Let AI handle the complex technical setup while you focus on creating content that converts visitors into customers.', 'sparkles'],
    'Content': ['Better content tools', 'Empower your team with user-friendly content creation tools designed specifically for marketers and content creators.', 'file-text'],
    'Media': ['Media integration', 'Manage images, videos, and documents effortlessly with powerful built-in media tools and automated optimization.', 'image'],
    'Privacy': ['Privacy compliance', 'GDPR, CCPA, and other privacy regulations handled automatically so you can focus on content, not compliance.', 'lock']
  };
  const [tab, setTab] = React.useState('Quick setup');
  const [title, body, icon] = features[tab];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '0 0 var(--section-y)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h1)',
      margin: '0 0 28px'
    }
  }, "Everything you need out-of-the-box"), /*#__PURE__*/React.createElement(Tabs, {
    variant: "pill",
    items: Object.keys(features),
    value: tab,
    onChange: setTab,
    style: {
      marginBottom: 32
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 48,
      alignItems: 'center',
      background: 'var(--surface-subtle)',
      borderRadius: 'var(--radius-xl)',
      padding: 48
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 36,
    color: "var(--drupal-blue)"
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h2)',
      margin: '16px 0 12px'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      margin: '0 0 20px',
      maxWidth: '42ch'
    }
  }, body), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    iconRight: "arrow-right"
  }, "Explore this feature")), /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '4/3',
      borderRadius: 'var(--radius-lg)',
      background: 'var(--gradient-yellow-light-blue)',
      display: 'flex',
      alignItems: 'flex-end',
      padding: 24,
      font: 'var(--text-body-sm)',
      color: 'var(--drupal-navy)'
    }
  }, "Feature illustration slot \u2014 ", tab))));
}
function CaseStudies() {
  const {
    StatBlock,
    Button,
    Badge
  } = DS;
  const studies = [['From WordPress Worries to Drupal CMS Confidence', 'SpecBee migrated DamFailures.org from WordPress to Drupal CMS, delivering an 88% performance boost and user-friendly content management that made their small non-technical team\'s work effortless.', [['88%', 'improvement in performance scores'], ['6', 'week redesign & migration']], 'var(--gradient-red-yellow)'], ['Digital impact in 8 weeks with Drupal CMS', 'Find out how Drupal CMS and Elevated Third helped Defend Public Health launch their mission-critical site lightning fast.', [['3,604', 'visitors in 3 weeks'], ['269', 'new email subscribers']], 'var(--gradient-purple-blue)']];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '0 0 var(--section-y)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 32
    }
  }, studies.map(([t, b, stats, grad], i) => /*#__PURE__*/React.createElement("article", {
    key: t,
    style: {
      display: 'grid',
      gridTemplateColumns: i % 2 ? '1fr 1.1fr' : '1.1fr 1fr',
      gap: 40,
      alignItems: 'center',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-xl)',
      overflow: 'hidden',
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 40,
      order: i % 2 ? 2 : 1
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "lavender",
    uppercase: false
  }, "Case study"), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h2)',
      margin: '16px 0 12px'
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      margin: '0 0 24px',
      maxWidth: '52ch'
    }
  }, b), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 48,
      marginBottom: 24
    }
  }, stats.map(([v, l]) => /*#__PURE__*/React.createElement(StatBlock, {
    key: v,
    value: v,
    label: l
  }))), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    iconRight: "arrow-right"
  }, "Learn more")), /*#__PURE__*/React.createElement("div", {
    style: {
      order: i % 2 ? 1 : 2,
      alignSelf: 'stretch',
      minHeight: 320,
      background: grad,
      display: 'flex',
      alignItems: 'flex-end',
      padding: 24,
      font: 'var(--text-body-sm)',
      color: 'var(--drupal-navy)'
    }
  }, "Customer site screenshot slot")))));
}
function GetStarted({
  onTrial
}) {
  const {
    Card,
    Button,
    Badge,
    StatBlock,
    Icon,
    PatternPanel
  } = DS;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '0 0 var(--section-y)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h1)',
      margin: '0 0 8px'
    }
  }, "Get started with Drupal"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      margin: '0 0 36px'
    }
  }, "Discover the power of Drupal and start creating exceptional digital experiences."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 24
    }
  }, [['Drupal CMS', 'Recommended for most websites', ['For marketers, content creators and site builders', 'Enterprise-grade quality in a CMS that\'s easy to use', 'Smart defaults to start quickly', 'Enhanced user-experience to guide you through setup'], 'Try Drupal CMS now', true], ['Drupal core', 'For advanced users and developers', ['Provides the building blocks for your digital experience', 'Start from scratch and customize around your vision', 'Make your own decisions around included features'], 'Build with Drupal core', false]].map(([t, sub, items, cta, primary]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      border: `2px solid ${primary ? 'var(--drupal-blue)' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-lg)',
      padding: 32,
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      background: 'var(--surface-card)'
    }
  }, primary && /*#__PURE__*/React.createElement(Badge, {
    tone: "brand"
  }, "Now available"), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h2)',
      margin: 0
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-muted)',
      margin: 0
    }
  }, sub), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      padding: 0,
      margin: '8px 0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, items.map(i => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: 'flex',
      gap: 10,
      font: 'var(--text-body-md)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 18,
    color: "var(--drupal-blue)",
    style: {
      marginTop: 3
    }
  }), i))), /*#__PURE__*/React.createElement(Button, {
    variant: primary ? 'primary' : 'outline',
    onClick: primary ? onTrial : undefined,
    style: {
      marginTop: 'auto',
      alignSelf: 'flex-start'
    }
  }, cta)))))), /*#__PURE__*/React.createElement(PatternPanel, {
    pattern: "blue-dense",
    background: "var(--drupal-navy)",
    basePath: A + '/png/patterns',
    opacity: .45,
    size: "cover"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: 'var(--space-20) 32px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h1)',
      color: 'var(--drupal-white)',
      margin: '0 0 12px'
    }
  }, "Trusted by the world's biggest brands"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 32,
      marginTop: 40
    }
  }, [['400k+', 'websites using Drupal today'], ['70%', 'Top 100 universities use Drupal'], ['100+', 'Drupal Certified Partners provide global support'], ['150+', 'Countries use Drupal']].map(([v, l]) => /*#__PURE__*/React.createElement(StatBlock, {
    key: v,
    value: v,
    label: l,
    tone: "inverse",
    align: "center"
  }))))));
}
Object.assign(window, {
  Hero,
  ReleaseBand,
  WhyGrid,
  FeatureTabs,
  CaseStudies,
  GetStarted
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/drupal-cms/Sections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/drupal-cms/SiteChrome.jsx
try { (() => {
const DS = window.DrupalDesignSystem_e0f3ad;
const A = '../../assets';
function TopBar({
  onTrial
}) {
  const {
    Logo,
    Button,
    IconButton,
    Icon
  } = DS;
  const [open, setOpen] = React.useState(null);
  const menus = {
    'Discover Drupal': [['Drupal Core', 'The open source framework behind millions of websites'], ['Drupal CMS', 'Drupal CMS puts the power of Drupal into the hands of marketers, designers and content creators'], ['Drupal AI', 'Open limitless possibilities with Drupal AI'], ['Case Studies', 'Powerful stories that show Drupal solutions in the real world']],
    'Build with Drupal': [['Download Drupal', 'Download Drupal and the extensions you need'], ['Documentation', 'Full knowledgebase including Drupal 7 resources'], ['Recipes', 'Automate module installation and configuration'], ['Site Templates', 'Complete, configured starting points for your Drupal website']],
    'Partners & Services': [['Find a Drupal Certified Partner', 'Connect with the best Drupal agencies around the world'], ['Find a Hosting Provider', 'Find a hosting provider for your Drupal project'], ['Find Training', 'Upskill your Drupal team']],
    'Community': [['About the Community', 'Come for the code, stay for the community'], ['DrupalCon', 'Network, learn, and be inspired'], ['Events', 'Discover local events, meet-ups, and training'], ['Slack', 'Get support and communicate with the global Drupal community']]
  };
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 30,
      background: 'var(--surface-page)',
      borderBottom: '1px solid var(--border-subtle)'
    },
    onMouseLeave: () => setOpen(null)
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 32,
      height: 76
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "drupal-horizontal",
    color: "navy",
    height: 30,
    basePath: A + '/png/logos'
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 6,
      flex: 1
    }
  }, Object.keys(menus).map(m => /*#__PURE__*/React.createElement("button", {
    key: m,
    onMouseEnter: () => setOpen(m),
    onClick: () => setOpen(open === m ? null : m),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      border: 0,
      background: 'transparent',
      cursor: 'pointer',
      padding: '8px 12px',
      borderRadius: 'var(--radius-sm)',
      font: 'var(--text-label)',
      color: open === m ? 'var(--drupal-blue)' : 'var(--drupal-navy)'
    }
  }, m, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 14
  })))), /*#__PURE__*/React.createElement(IconButton, {
    icon: "search",
    label: "Search"
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      font: 'var(--text-label)',
      color: 'var(--drupal-navy)',
      textDecoration: 'none'
    }
  }, "Log in"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    onClick: onTrial
  }, "Try Drupal CMS")), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      background: 'var(--surface-page)',
      borderTop: '1px solid var(--border-subtle)',
      borderBottom: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-md)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 24,
      padding: '28px 32px 32px'
    }
  }, menus[open].map(([t, d]) => /*#__PURE__*/React.createElement("a", {
    key: t,
    href: "#",
    style: {
      textDecoration: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-label)',
      color: 'var(--drupal-blue)'
    }
  }, t), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, d))))));
}
function SiteFooter() {
  const {
    Logo
  } = DS;
  const cols = [['Drupal', ['About Drupal', 'Code of Conduct', 'News', 'Planet Drupal']], ['Build', ['Download', 'Documentation', 'Modules', 'Recipes']], ['Community', ['Events', 'DrupalCon', 'Slack', 'Forum']], ['Association', ['Donate', 'Become a member', 'Certified Partners', 'Sustaining members']]];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--drupal-navy)',
      color: 'var(--text-inverse)',
      marginTop: 'var(--space-24)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '64px 32px 40px',
      display: 'grid',
      gridTemplateColumns: '1.4fr repeat(4,1fr)',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "drupal-horizontal",
    color: "white",
    height: 30,
    basePath: A + '/png/logos'
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'rgba(255,255,255,.72)',
      maxWidth: '34ch',
      margin: 0
    }
  }, "Drupal is an open source platform for building amazing digital experiences. It's made by a dedicated community. Anyone can use it, and it will always be free.")), cols.map(([h, items]) => /*#__PURE__*/React.createElement("div", {
    key: h,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: 'var(--blue-pale)'
    }
  }, h), items.map(i => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    style: {
      font: 'var(--text-body-sm)',
      color: 'rgba(255,255,255,.86)',
      textDecoration: 'none'
    }
  }, i))))), /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '20px 32px 40px',
      borderTop: '1px solid var(--border-inverse)',
      display: 'flex',
      justifyContent: 'space-between',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'rgba(255,255,255,.6)'
    }
  }, "Drupal is a registered trademark of Dries Buytaert."), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'rgba(255,255,255,.6)'
    }
  }, "Copyright 2026")));
}
Object.assign(window, {
  TopBar,
  SiteFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/drupal-cms/SiteChrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/drupal-org/OrgChrome.jsx
try { (() => {
const DS = window.DrupalDesignSystem_e0f3ad;
const A = '../../assets';
function OrgHeader({
  route,
  go
}) {
  const {
    Logo,
    Button,
    Input,
    Icon
  } = DS;
  const nav = [['home', 'Home'], ['browse', 'Modules'], ['project', 'Project'], ['docs', 'Documentation'], ['community', 'Community']];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      background: 'var(--drupal-navy)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 24,
      padding: '16px 32px'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go('home');
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "drupal-horizontal",
    color: "white",
    height: 28,
    basePath: A + '/png/logos'
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 4,
      flex: 1
    }
  }, nav.map(([k, l]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    onClick: () => go(k),
    style: {
      border: 0,
      cursor: 'pointer',
      padding: '8px 14px',
      borderRadius: 'var(--radius-pill)',
      font: 'var(--text-label)',
      background: route === k ? 'rgba(255,255,255,.14)' : 'transparent',
      color: route === k ? 'var(--drupal-white)' : 'rgba(255,255,255,.8)'
    }
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 250
    }
  }, /*#__PURE__*/React.createElement(Input, {
    iconLeft: "search",
    placeholder: "Search Drupal.org",
    "aria-label": "Search Drupal.org"
  })), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "inverse"
  }, "Log in")));
}
function OrgFooter() {
  const cols = [['News items', ['News', 'Planet Drupal', 'Social media', 'Security advisories']], ['Our community', ['Community', 'Services & training', 'Contributor guide', 'DrupalCon']], ['Documentation', ['Documentation', 'Drupal Guide', 'Developer docs', 'API.Drupal.org']], ['Drupal code base', ['Download & Extend', 'Drupal core', 'Modules', 'Themes']]];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      background: 'var(--surface-subtle)',
      marginTop: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 32,
      padding: '48px 32px'
    }
  }, cols.map(([h, items]) => /*#__PURE__*/React.createElement("div", {
    key: h,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, h), items.map(i => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    style: {
      font: 'var(--text-body-sm)'
    }
  }, i))))), /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '0 32px 40px',
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, "Drupal is a registered trademark of Dries Buytaert. Infrastructure management for Drupal.org provided by Tag1."));
}
Object.assign(window, {
  OrgHeader,
  OrgFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/drupal-org/OrgChrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/drupal-org/OrgScreens.jsx
try { (() => {
const DS = window.DrupalDesignSystem_e0f3ad;
const A = '../../assets';
function OrgHome({
  go
}) {
  const {
    Button,
    Card,
    Badge,
    GuiBlock,
    StatBlock,
    PatternPanel,
    Icon
  } = DS;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PatternPanel, {
    pattern: "grey-light",
    background: "var(--surface-page)",
    basePath: A + '/png/patterns',
    size: "cover",
    opacity: .55
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: '1.1fr .9fr',
      gap: 48,
      alignItems: 'center',
      padding: '72px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "brand"
  }, "Drupal CMS 2.0 is available"), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-display)',
      margin: 0,
      maxWidth: '20ch',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, "Build ambitious digital experiences"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      margin: 0,
      maxWidth: '48ch'
    }
  }, "Drupal is an open source platform for building amazing digital experiences. It's made by a dedicated community. Anyone can use it, and it will always be free."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    iconRight: "arrow-right",
    onClick: () => go('browse')
  }, "Get started"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "outline",
    onClick: () => go('docs')
  }, "Read the docs"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(GuiBlock, {
    tone: "blue",
    size: 320,
    radius: 54
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-h3)'
    }
  }, "400k+ sites"))))), /*#__PURE__*/React.createElement("section", {
    className: "wrap",
    style: {
      padding: 'var(--section-y-sm) 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24
    }
  }, [['Drupal Core', 'The open source framework behind millions of websites.', 'box'], ['Drupal CMS', 'Ready-to-use platform for marketing teams, content creators and site builders.', 'rocket'], ['Drupal AI', 'Open limitless possibilities with Drupal AI.', 'sparkles']].map(([t, b, ic]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    padding: 28,
    href: "#",
    linkLabel: "Learn more"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 30,
    color: "var(--drupal-blue)"
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h4)',
      margin: '12px 0 6px'
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      margin: 0
    }
  }, b))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-subtle)',
      padding: 'var(--space-16) 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 24
    }
  }, [['400k+', 'websites using Drupal today'], ['70%', 'Top 100 universities use Drupal'], ['100+', 'Drupal Certified Partners'], ['150+', 'countries use Drupal']].map(([v, l]) => /*#__PURE__*/React.createElement(StatBlock, {
    key: v,
    value: v,
    label: l
  })))), /*#__PURE__*/React.createElement("section", {
    className: "wrap",
    style: {
      padding: 'var(--section-y-sm) 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h2)',
      margin: 0
    }
  }, "News & blogs"), /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "All news")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24
    }
  }, [['Drupal CMS 2.0 is here: visual building, AI and site templates', 'Release', 'var(--gradient-navy-blue)'], ['DrupalCon Europe 2026 lands in Rotterdam', 'Events', 'var(--gradient-red-yellow)'], ['The 2026 Drupal Business Survey is open', 'Association', 'var(--gradient-purple-blue)']].map(([t, tag, g]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    eyebrow: tag,
    title: t,
    href: "#",
    linkLabel: "Read the post",
    media: /*#__PURE__*/React.createElement("div", {
      style: {
        height: '100%',
        background: g
      }
    })
  })))));
}
function BrowseModules({
  go
}) {
  const {
    Tabs,
    Input,
    Select,
    Tag,
    Card,
    Badge,
    Button,
    Icon,
    Checkbox
  } = DS;
  const all = [['Views Bulk Operations', 'Adds an "Action" dropdown to Views for bulk operations on selected rows.', ['Site building', 'Views'], '42,318'], ['Metatag', 'Automatically provide structured metadata, aka meta tags, about your website.', ['SEO'], '318,204'], ['Paragraphs', 'Create flexible, structured content with reusable paragraph types.', ['Content', 'Site building'], '271,553'], ['Webform', 'Build any type of form, from a simple contact form to complex multi-step workflows.', ['Forms'], '404,127'], ['Search API', 'Provides a generic framework for modular search implementations.', ['Search'], '188,940'], ['AI Agents', 'Agentic AI building blocks for Drupal CMS site building tasks.', ['AI', 'Experimental'], '6,412']];
  const [q, setQ] = React.useState('');
  const [tab, setTab] = React.useState('Modules');
  const list = all.filter(m => m[0].toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '40px 32px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-h1)',
      margin: '0 0 8px'
    }
  }, "Download & Extend"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      margin: '0 0 24px'
    }
  }, "Extend your project's functionality with 50,000+ community modules, themes and recipes."), /*#__PURE__*/React.createElement(Tabs, {
    variant: "pill",
    items: ['Modules', 'Themes', 'Recipes', 'Site templates', 'Distributions'],
    value: tab,
    onChange: setTab,
    style: {
      marginBottom: 28
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '260px 1fr',
      gap: 32,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement(Input, {
    iconLeft: "search",
    placeholder: "Filter by name",
    value: q,
    onChange: e => setQ(e.target.value),
    "aria-label": "Filter modules"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Core compatibility",
    options: ['Drupal 11', 'Drupal 10', 'Drupal 7']
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-label)'
    }
  }, "Status"), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Stable releases",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Security covered",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Experimental"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, ['SEO', 'Content', 'Views', 'AI', 'Forms'].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    onClick: () => {}
  }, t)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, list.length, " of 50,214 ", tab.toLowerCase()), /*#__PURE__*/React.createElement(Select, {
    options: ['Most installed', 'Recently updated', 'A–Z'],
    style: {
      width: 200
    }
  })), list.map(([n, d, tags, installs]) => /*#__PURE__*/React.createElement("div", {
    key: n,
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'flex-start',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: '20px 24px',
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 44,
      height: 44,
      borderRadius: 'var(--radius-sm)',
      background: 'var(--surface-accent-tint)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "package",
    size: 22,
    color: "var(--drupal-blue)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => go('project'),
    style: {
      border: 0,
      background: 'transparent',
      padding: 0,
      cursor: 'pointer',
      font: 'var(--text-h4)',
      color: 'var(--text-link)'
    }
  }, n), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      margin: '6px 0 10px'
    }
  }, d), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, tags.map(t => /*#__PURE__*/React.createElement(Badge, {
    key: t,
    tone: "neutral",
    uppercase: false
  }, t)), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, installs, " sites"))), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "outline"
  }, "Install"))))));
}
function ProjectPage({
  go
}) {
  const {
    Breadcrumbs,
    Badge,
    Button,
    Tabs,
    Card,
    Icon,
    Tooltip,
    IconButton
  } = DS;
  const [tab, setTab] = React.useState('Overview');
  return /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '28px 32px'
    }
  }, /*#__PURE__*/React.createElement(Breadcrumbs, {
    items: [{
      label: 'Drupal.org',
      href: '#'
    }, {
      label: 'Download & Extend',
      href: '#'
    }, {
      label: 'Metatag'
    }],
    style: {
      marginBottom: 20
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 40,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-h1)',
      margin: 0
    }
  }, "Metatag"), /*#__PURE__*/React.createElement(Badge, {
    tone: "brand"
  }, "Security covered"), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral",
    uppercase: false
  }, "Drupal 11 \xB7 Drupal 10")), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      margin: '12px 0 24px',
      maxWidth: '62ch'
    }
  }, "Automatically provide structured metadata, aka meta tags, about your website. In the context of search engine optimization, this module gives you fine-grained control over the meta tags output for every page."), /*#__PURE__*/React.createElement(Tabs, {
    items: ['Overview', 'Releases', 'Issues', 'Documentation', 'Automated testing'],
    value: tab,
    onChange: setTab,
    style: {
      marginBottom: 24
    }
  }), tab === 'Releases' ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, [['2.1.0', 'Recommended', '11 Aug 2026'], ['2.0.3', 'Also available', '2 Mar 2026'], ['1.26.0', 'Legacy', '14 Sep 2024']].map(([v, s, d]) => /*#__PURE__*/React.createElement("div", {
    key: v,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: '16px 20px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-h4)',
      minWidth: 80
    }
  }, v), /*#__PURE__*/React.createElement(Badge, {
    tone: s === 'Recommended' ? 'brand' : 'neutral',
    uppercase: false
  }, s), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      flex: 1
    }
  }, d), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    iconLeft: "download"
  }, "tar.gz")))) : tab === 'Issues' ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, [['Support for Drupal 11.4', 'Active', 'Task', 'Normal'], ['Meta tags missing on taxonomy pages', 'Needs review', 'Bug report', 'Major'], ['Add JSON-LD output option', 'Needs work', 'Feature request', 'Normal']].map(([t, s, k, p]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'center',
      padding: '14px 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-dot",
    size: 18,
    color: "var(--drupal-blue)"
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      flex: 1,
      font: 'var(--text-body-md)'
    }
  }, t), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral",
    uppercase: false
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      width: 100
    }
  }, s), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      width: 60
    }
  }, p)))) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h3)',
      margin: 0
    }
  }, "What it does"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      margin: 0,
      maxWidth: '70ch'
    }
  }, "Metatag adds a configurable set of meta tags to every content type, view and entity on your site: page title, description, canonical URL, Open Graph, Twitter cards, Dublin Core and more. Defaults cascade from global configuration down to individual entities, so editors only override what they need."), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h4)',
      margin: '8px 0 0'
    }
  }, "Install with Composer"), /*#__PURE__*/React.createElement("pre", {
    style: {
      margin: 0,
      padding: '16px 20px',
      background: 'var(--drupal-navy)',
      color: 'var(--blue-pale)',
      borderRadius: 'var(--radius-md)',
      font: 'var(--text-body-sm)',
      fontFamily: 'var(--font-mono)',
      overflowX: 'auto'
    }
  }, "composer require drupal/metatag && drush en metatag"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 20,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(Card, {
    tone: "tint",
    padding: 22,
    title: "Recipes",
    body: "Ship Metatag pre-configured through the SEO recipe in Drupal CMS."
  }), /*#__PURE__*/React.createElement(Card, {
    tone: "tint",
    padding: 22,
    title: "Maintainers",
    body: "Maintained by 4 people with 1,240 commits over 14 years."
  })))), /*#__PURE__*/React.createElement("aside", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      padding: 24,
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    iconLeft: "download"
  }, "Download 2.1.0"), /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    variant: "outline",
    onClick: () => go('docs')
  }, "Read documentation"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Tooltip, {
    label: "Copy install command"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "copy",
    label: "Copy install command",
    variant: "outline"
  })), /*#__PURE__*/React.createElement(Tooltip, {
    label: "Star this project"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "star",
    label: "Star project",
    variant: "outline"
  })), /*#__PURE__*/React.createElement(Tooltip, {
    label: "Report an issue"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "bug",
    label: "Report an issue",
    variant: "outline"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      paddingTop: 8,
      borderTop: '1px solid var(--border-subtle)'
    }
  }, [['Reported installs', '318,204 sites'], ['Downloads', '12.4M'], ['Last release', '11 Aug 2026'], ['Open issues', '86 of 3,214'], ['Maintenance', 'Actively maintained']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      font: 'var(--text-body-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-strong)'
    }
  }, v)))))));
}
function DocsPage() {
  const {
    Breadcrumbs,
    Tag,
    Icon,
    Card
  } = DS;
  const toc = ['What is a recipe?', 'Applying a recipe', 'Writing your own', 'Recipe reference', 'Troubleshooting'];
  return /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '28px 32px'
    }
  }, /*#__PURE__*/React.createElement(Breadcrumbs, {
    items: [{
      label: 'Documentation',
      href: '#'
    }, {
      label: 'Drupal CMS',
      href: '#'
    }, {
      label: 'Recipes'
    }],
    style: {
      marginBottom: 24
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '240px 1fr 220px',
      gap: 40,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, ['Getting started', 'Installing Drupal', 'Drupal CMS', 'Recipes', 'Site templates', 'Theming', 'Upgrading'].map((s, i) => /*#__PURE__*/React.createElement("a", {
    key: s,
    href: "#",
    style: {
      font: 'var(--text-body-md)',
      padding: '8px 12px',
      borderRadius: 'var(--radius-sm)',
      textDecoration: 'none',
      background: i === 3 ? 'var(--surface-accent-tint)' : 'transparent',
      color: i === 3 ? 'var(--drupal-navy)' : 'var(--text-link)'
    }
  }, s))), /*#__PURE__*/React.createElement("article", {
    style: {
      maxWidth: '70ch'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-h1)',
      margin: '0 0 12px'
    }
  }, "Recipes"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      margin: '0 0 24px'
    }
  }, "Recipes are pre-configured packages of modules, configuration and content that enable ambitious site builders to set up customized, performant websites quickly."), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h3)',
      margin: '32px 0 12px'
    }
  }, "What is a recipe?"), /*#__PURE__*/React.createElement("p", null, "A recipe is a directory containing a ", /*#__PURE__*/React.createElement("code", {
    style: {
      fontFamily: 'var(--font-mono)',
      background: 'var(--surface-subtle)',
      padding: '2px 6px',
      borderRadius: 4
    }
  }, "recipe.yml"), " file plus optional configuration and content. Applying a recipe installs the modules it depends on, imports its configuration, and creates any default content \u2014 then gets out of the way. Recipes are not a dependency: once applied, your site owns the result."), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h3)',
      margin: '32px 0 12px'
    }
  }, "Applying a recipe"), /*#__PURE__*/React.createElement("pre", {
    style: {
      margin: '0 0 20px',
      padding: '16px 20px',
      background: 'var(--drupal-navy)',
      color: 'var(--blue-pale)',
      borderRadius: 'var(--radius-md)',
      font: 'var(--text-body-sm)',
      fontFamily: 'var(--font-mono)',
      overflowX: 'auto'
    }
  }, "php core/scripts/drupal recipe recipes/seo_basic"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start',
      padding: '18px 20px',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-accent-tint)',
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "info",
    size: 20,
    color: "var(--drupal-blue)",
    style: {
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: 'var(--text-body-md)'
    }
  }, "Recipes are applied once. To keep changes reversible, apply them on a development site first and export the resulting configuration.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      marginTop: 32
    }
  }, ['Recipes', 'Site building', 'Drupal CMS', 'Configuration'].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t)))), /*#__PURE__*/React.createElement("aside", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      position: 'sticky',
      top: 24
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, "On this page"), toc.map((t, i) => /*#__PURE__*/React.createElement("a", {
    key: t,
    href: "#",
    style: {
      font: 'var(--text-body-sm)',
      textDecoration: 'none',
      color: i === 0 ? 'var(--drupal-navy)' : 'var(--text-link)',
      borderLeft: `2px solid ${i === 0 ? 'var(--drupal-blue)' : 'var(--border-subtle)'}`,
      paddingLeft: 12
    }
  }, t)), /*#__PURE__*/React.createElement(Card, {
    tone: "tint",
    padding: 18,
    title: "Help improve this page",
    body: "Documentation is written by the community.",
    href: "#",
    linkLabel: "Edit on Drupal.org",
    style: {
      marginTop: 16
    }
  }))));
}
function CommunityPage() {
  const {
    PatternPanel,
    Card,
    Button,
    StatBlock,
    Badge
  } = DS;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PatternPanel, {
    pattern: "blue-multiply",
    background: "var(--drupal-navy)",
    basePath: A + '/png/patterns',
    opacity: .5
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '72px 32px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-display)',
      color: 'var(--drupal-white)',
      margin: '0 0 12px'
    }
  }, "Come for the code, stay for the community"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      color: 'rgba(255,255,255,.85)',
      maxWidth: '56ch',
      margin: '0 auto'
    }
  }, "Drupal is made by a dedicated community of developers, marketers, designers and contributors in more than 150 countries."))), /*#__PURE__*/React.createElement("section", {
    className: "wrap",
    style: {
      padding: 'var(--section-y-sm) 32px',
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24
    }
  }, [['How to contribute', 'Get involved in growing and evolving Drupal.'], ['Events', 'Discover local events, community meet-ups, and training.'], ['Slack', 'Get support and communicate with the global Drupal community.']].map(([t, b]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    title: t,
    body: b,
    href: "#",
    padding: 28
  }))), /*#__PURE__*/React.createElement("section", {
    className: "wrap",
    style: {
      padding: '0 32px var(--section-y-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 32,
      background: 'var(--surface-subtle)',
      borderRadius: 'var(--radius-xl)',
      padding: '40px 48px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Badge, {
    tone: "yellow"
  }, "DrupalCon Europe"), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h2)',
      margin: '14px 0 8px'
    }
  }, "Rotterdam, 28 September \u2013 1 October 2026"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      margin: 0,
      maxWidth: '52ch'
    }
  }, "DrupalCon unites experts from around the globe who create ambitious digital experiences.")), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    iconRight: "arrow-right"
  }, "Learn more"))));
}
Object.assign(window, {
  OrgHome,
  BrowseModules,
  ProjectPage,
  DocsPage,
  CommunityPage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/drupal-org/OrgScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/drupalcon/EventScreens.jsx
try { (() => {
const DS = window.DrupalDesignSystem_e0f3ad;
const A = '../../assets';
function EventHeader({
  route,
  go,
  onRegister
}) {
  const {
    Logo,
    Button
  } = DS;
  const nav = [['home', 'Home'], ['program', 'Program'], ['register', 'Register']];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      borderBottom: '1px solid var(--border-subtle)',
      background: 'var(--surface-page)',
      position: 'sticky',
      top: 0,
      zIndex: 30
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 28,
      height: 72
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go('home');
    },
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "drop",
    color: "blue",
    height: 30,
    basePath: A + '/png/logos'
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-h4)',
      color: 'var(--drupal-navy)'
    }
  }, "Drupal Events")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 22,
      flex: 1,
      marginLeft: 12
    }
  }, nav.map(([k, l]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    onClick: () => go(k),
    style: {
      border: 0,
      background: 'transparent',
      cursor: 'pointer',
      font: 'var(--text-label)',
      padding: '6px 0',
      color: route === k ? 'var(--drupal-blue)' : 'var(--drupal-navy)',
      boxShadow: route === k ? 'inset 0 -3px 0 0 var(--drupal-blue)' : 'none'
    }
  }, l))), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, "Rotterdam \xB7 28 Sep \u2013 1 Oct 2026"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    onClick: onRegister
  }, "Register")));
}
function EventHome({
  go,
  onRegister
}) {
  const {
    Button,
    Badge,
    Card,
    StatBlock,
    PatternPanel,
    GuiBlock,
    Icon
  } = DS;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--drupal-navy)',
      color: 'var(--text-inverse)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: '1.1fr .9fr',
      gap: 48,
      alignItems: 'center',
      padding: '80px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "yellow"
  }, "DrupalCon Europe 2026"), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-display)',
      color: 'var(--drupal-white)',
      margin: 0,
      maxWidth: '20ch',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, "Where the art of the possible comes to life."), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      color: 'rgba(255,255,255,.85)',
      maxWidth: '50ch',
      margin: 0
    }
  }, "DrupalCon unites experts from around the globe who create ambitious digital experiences. Network, learn, and be inspired."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "inverse",
    onClick: onRegister
  }, "Register now"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "ghost",
    style: {
      color: 'var(--blue-pale)'
    },
    onClick: () => go('program')
  }, "See the program"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(GuiBlock, {
    tone: "yellow",
    size: 330,
    radius: 56
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-h3)'
    }
  }, "Rotterdam", /*#__PURE__*/React.createElement("br", null), "28 Sep \u2013 1 Oct"))))), /*#__PURE__*/React.createElement("section", {
    className: "wrap",
    style: {
      padding: 'var(--section-y-sm) 32px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h2)',
      margin: '0 0 24px'
    }
  }, "Upcoming events"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24
    }
  }, [['DrupalCon Rotterdam', '28 September – 1 October 2026', 'DrupalCon Europe 2026 lands in Rotterdam! Experience the perfect mix of innovation, creativity, and community in one of Europe\'s most modern and inspiring cities.', 'var(--gradient-navy-blue)'], ['DrupalCon Orlando', '22–25 March 2027', 'Orlando is a city defined by the journey from a simple spark of imagination to a world-class reality. Join a strong local community in a Human Rights Campaign 100 city.', 'var(--gradient-red-yellow)'], ['Community events', 'All year, worldwide', 'The Drupal community organizes events all over the globe, both virtually and in-person. Find an event near you, or submit your own.', 'var(--gradient-purple-blue)']].map(([t, d, b, g]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    eyebrow: d,
    title: t,
    body: b,
    href: "#",
    linkLabel: "Learn more",
    media: /*#__PURE__*/React.createElement("div", {
      style: {
        height: '100%',
        background: g
      }
    })
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-subtle)',
      padding: 'var(--space-16) 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-h3)',
      margin: '0 0 28px'
    }
  }, "What is DrupalCon?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 32
    }
  }, [['32', 'events since 2005'], ['3000', 'attendees on average'], ['165', 'sessions per event']].map(([v, l]) => /*#__PURE__*/React.createElement(StatBlock, {
    key: v,
    value: v,
    label: l
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24,
      marginTop: 40
    }
  }, [['Keynotes & Sessions', 'for leaders, developers, and end users', 'mic'], ['Summits & Training', 'industry-focused to elevate your skill', 'graduation-cap'], ['Networking & Collaboration', 'that you can only find at DrupalCon', 'users']].map(([t, b, ic]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 26,
    color: "var(--drupal-blue)",
    style: {
      marginTop: 3
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h4)',
      margin: '0 0 4px'
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      margin: 0
    }
  }, b))))))), /*#__PURE__*/React.createElement(PatternPanel, {
    pattern: "lavender-mix",
    background: "var(--surface-page)",
    basePath: A + '/png/patterns',
    size: "cover",
    opacity: .7
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: 'var(--space-20) 32px'
    }
  }, /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      maxWidth: '46ch'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--weight-display-semibold) 30px/1.35 var(--font-display)',
      color: 'var(--drupal-navy)',
      margin: '0 0 16px'
    }
  }, "\"Before meeting and working together with people at DrupalCon, they were colleagues, but then I learned so much working in person, and they became more like family.\""), /*#__PURE__*/React.createElement("footer", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-body)'
    }
  }, "Tushar Thatikonda \xB7 2019 Grant Recipient")))));
}
function ProgramPage() {
  const {
    Tabs,
    Badge,
    Tag,
    Card,
    Icon
  } = DS;
  const days = {
    'Mon 28 Sep': [['09:00', 'Registration & coffee', 'Foyer', 'Community'], ['10:00', 'Opening keynote: the art of the possible', 'Main hall', 'Keynote'], ['11:30', 'Drupal Canvas in production', 'Room 1', 'Session'], ['13:00', 'Lunch & Birds of a Feather', 'Expo', 'BoF'], ['14:30', 'Governing AI in Drupal CMS', 'Room 2', 'Session']],
    'Tue 29 Sep': [['09:30', 'Driesnote', 'Main hall', 'Keynote'], ['11:00', 'Site templates: from install to launch in 3 minutes', 'Room 1', 'Session'], ['12:30', 'Higher education summit', 'Room 4', 'Summit'], ['15:00', 'Contribution mentoring', 'Contribution room', 'Contribution']],
    'Wed 30 Sep': [['09:30', 'Marketing with Drupal CMS', 'Room 2', 'Session'], ['11:00', 'Accessibility clinic', 'Room 3', 'Training'], ['13:30', 'Agency leadership panel', 'Main hall', 'Panel'], ['16:00', 'Trivia night', 'Expo', 'Social']],
    'Thu 1 Oct': [['09:30', 'Contribution day kick-off', 'Contribution room', 'Contribution'], ['10:00', 'Sprints', 'Contribution room', 'Contribution'], ['15:00', 'Closing session', 'Main hall', 'Keynote']]
  };
  const [day, setDay] = React.useState('Mon 28 Sep');
  const [track, setTrack] = React.useState('All tracks');
  const tracks = ['All tracks', 'Keynote', 'Session', 'Summit', 'Contribution'];
  const rows = days[day].filter(r => track === 'All tracks' || r[3] === track);
  return /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '40px 32px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-h1)',
      margin: '0 0 8px'
    }
  }, "Program"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      margin: '0 0 28px',
      maxWidth: '56ch'
    }
  }, "Whether you're a C-level, a developer, a content strategist, or a marketer\u2014there's something for you at DrupalCon."), /*#__PURE__*/React.createElement(Tabs, {
    items: Object.keys(days),
    value: day,
    onChange: setDay,
    style: {
      marginBottom: 20
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      marginBottom: 24
    }
  }, tracks.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    selected: t === track,
    onClick: () => setTrack(t)
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 300px',
      gap: 32,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, rows.map(([time, title, room, tag]) => /*#__PURE__*/React.createElement("div", {
    key: title,
    style: {
      display: 'grid',
      gridTemplateColumns: '80px 1fr auto',
      gap: 20,
      alignItems: 'center',
      padding: '20px 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-label)',
      color: 'var(--drupal-blue)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, time), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-h4)',
      margin: '0 0 4px'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 6,
      alignItems: 'center',
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "map-pin",
    size: 14
  }), room)), /*#__PURE__*/React.createElement(Badge, {
    tone: tag === 'Keynote' ? 'navy' : tag === 'Contribution' ? 'coral' : 'tint',
    uppercase: false
  }, tag))), rows.length === 0 && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-muted)'
    }
  }, "No sessions in this track on ", day, ".")), /*#__PURE__*/React.createElement("aside", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    tone: "tint",
    padding: 22,
    title: "Birds of a Feather",
    body: "Informal gatherings of like-minded people who want to discuss a specific topic without an agenda.",
    href: "#",
    linkLabel: "Propose a BoF"
  }), /*#__PURE__*/React.createElement(Card, {
    tone: "navy",
    padding: 22,
    title: "Contribution Day",
    body: "A working meeting focused on the project \u2014 a great way to get involved, with mentors on hand.",
    href: "#",
    linkLabel: "Join a sprint"
  }))));
}
function RegisterPage() {
  const {
    Input,
    Select,
    Checkbox,
    Radio,
    Button,
    Badge,
    Toast,
    Icon
  } = DS;
  const [tier, setTier] = React.useState('standard');
  const [sent, setSent] = React.useState(false);
  const tiers = [['early', 'Early bird', '€ 545', 'Ends 30 June 2026'], ['standard', 'Standard', '€ 695', 'Full four-day access'], ['contributor', 'Contributor', '€ 145', 'For active project contributors']];
  return /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '40px 32px',
      display: 'grid',
      gridTemplateColumns: '1.15fr .85fr',
      gap: 48,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-h1)',
      margin: '0 0 8px'
    }
  }, "Register for DrupalCon Rotterdam"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-lead)',
      margin: '0 0 28px'
    }
  }, "Four days of keynotes, sessions, summits and contribution \u2014 28 September to 1 October 2026."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      marginBottom: 32
    }
  }, tiers.map(([k, name, price, note]) => /*#__PURE__*/React.createElement("label", {
    key: k,
    onClick: () => setTier(k),
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'center',
      cursor: 'pointer',
      border: `2px solid ${tier === k ? 'var(--drupal-blue)' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-lg)',
      padding: '20px 24px',
      background: tier === k ? 'var(--surface-accent-tint)' : 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement(Radio, {
    name: "tier",
    value: k,
    checked: tier === k,
    onChange: () => setTier(k)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-h4)',
      display: 'block'
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, note)), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-h3)',
      color: 'var(--drupal-navy)'
    }
  }, price)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "First name",
    placeholder: "Ada"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Last name",
    placeholder: "Lovelace"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    placeholder: "you@example.com",
    style: {
      gridColumn: '1 / -1'
    }
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Organization",
    placeholder: "Acquia"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Country",
    placeholder: "Select a country",
    options: ['Netherlands', 'Germany', 'United Kingdom', 'United States', 'India']
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Dietary needs",
    placeholder: "None",
    options: ['Vegetarian', 'Vegan', 'Gluten free', 'Other']
  }), /*#__PURE__*/React.createElement(Select, {
    label: "T-shirt size",
    placeholder: "Select a size",
    options: ['S', 'M', 'L', 'XL', 'XXL']
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      margin: '24px 0 28px'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "I agree to the Code of Conduct",
    description: "Required for all attendees.",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Add me to the DrupalCon newsletter"
  })), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    iconRight: "arrow-right",
    onClick: () => setSent(true)
  }, "Continue to payment"), sent && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      right: 24,
      bottom: 24,
      zIndex: 70
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "success",
    title: "Registration held",
    message: "Your spot is reserved for 30 minutes while you pay.",
    onClose: () => setSent(false)
  }))), /*#__PURE__*/React.createElement("aside", {
    style: {
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      padding: 28,
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      background: 'var(--surface-card)',
      position: 'sticky',
      top: 96
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "yellow"
  }, "Order summary"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: 'var(--text-body-md)'
    }
  }, /*#__PURE__*/React.createElement("span", null, tiers.find(t => t[0] === tier)[1], " ticket"), /*#__PURE__*/React.createElement("span", null, tiers.find(t => t[0] === tier)[2])), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: 'var(--text-body-md)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "VAT (21%)"), /*#__PURE__*/React.createElement("span", null, "calculated at payment")), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      paddingTop: 14,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, ['Four days of sessions and keynotes', 'Summits and contribution day', 'Expo hall and evening socials', 'Session recordings after the event'].map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      display: 'flex',
      gap: 10,
      font: 'var(--text-body-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 16,
    color: "var(--drupal-blue)",
    style: {
      marginTop: 2
    }
  }), i)))));
}
function EventFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--drupal-navy)',
      color: 'rgba(255,255,255,.8)',
      marginTop: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '48px 32px',
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 28
    }
  }, [['Policies', ['Code of Conduct', 'Privacy Policy', 'Terms of Service', 'Media Policy', 'Photo Credits']], ['Contact', ['Contact the team', 'Sponsorship', 'Press']], ['Connect', ['Facebook', 'LinkedIn', 'Instagram', 'YouTube']], ['Community', ['Drupal.org', 'Community events', 'Groups & meetups', 'Slack']]].map(([h, items]) => /*#__PURE__*/React.createElement("div", {
    key: h,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: 'var(--blue-pale)'
    }
  }, h), items.map(i => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    style: {
      font: 'var(--text-body-sm)',
      color: 'rgba(255,255,255,.82)',
      textDecoration: 'none'
    }
  }, i))))), /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '0 32px 40px',
      font: 'var(--text-body-sm)',
      color: 'rgba(255,255,255,.6)',
      maxWidth: '70ch'
    }
  }, "DrupalCon is brought to you by the Drupal Association with support from our generous sponsors and an amazing team of contributors."));
}
Object.assign(window, {
  EventHeader,
  EventHome,
  ProgramPage,
  RegisterPage,
  EventFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/drupalcon/EventScreens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.DropWindow = __ds_scope.DropWindow;

__ds_ns.GuiBlock = __ds_scope.GuiBlock;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.PatternPanel = __ds_scope.PatternPanel;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.Tabs = __ds_scope.Tabs;

})();

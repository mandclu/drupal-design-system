# Sample slides — Drupal brand deck

Eight slide types at 1280×720, each a standalone HTML file so it can be reordered, exported or
copied into a deck. `index.html` plays them with arrow keys and remembers your place.

| File | Type | Notes |
| --- | --- | --- |
| `title.html` | Title | Navy + dynamic pattern, white horizontal logo |
| `section.html` | Section divider | Yellow field, oversized ghosted number |
| `bullets.html` | Bullets | Heading + checked list, GUI-block screenshot slot |
| `comparison.html` | Comparison | Drupal CMS vs Drupal core, blue-outlined recommended card |
| `stats.html` | Stats | Four proof figures on the dark→light blue gradient |
| `quote.html` | Big quote | Display-weight quote over the lavender pattern |
| `image-feature.html` | Image feature | Navy caption panel + full-bleed image slot |
| `closing.html` | Closing | Drop mark, community line, URLs |

Rules: one accent background per deck run (yellow section breaks, navy openers/closers); minimum
text size 24px; ZT Gatha for every headline and figure, Noto Sans for body. Screenshot and photo
areas are labelled slots — drop real imagery in rather than generating it.

The brand portal's own "Slide Deck Template" asset is a GUI-block cover graphic only
(`assets/graphics/Slide-Deck-Template-Button.png`); the actual master deck was not in the export, so
these layouts are built from the brand foundations.

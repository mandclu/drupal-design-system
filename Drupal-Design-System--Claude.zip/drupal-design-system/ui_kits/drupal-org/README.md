# UI kit — Drupal.org

Five community-site surfaces, composed from this system's primitives.

## Screens
- `OrgChrome.jsx` — `OrgHeader` (navy bar, route pills, inline search, log in) and `OrgFooter` (four link columns + Tag1 infrastructure line).
- `OrgScreens.jsx`
  - `OrgHome` — hero, three product cards (Core / CMS / AI), proof stats, news teasers.
  - `BrowseModules` — Download & Extend: pill tabs, live name filter, facet sidebar (core compatibility, status checkboxes, topic tags), result rows with install counts.
  - `ProjectPage` — project header with security/compat badges, tabbed Overview / Releases / Issues, composer snippet, sticky sidebar of project stats.
  - `DocsPage` — three-column documentation article with section nav, prose, callout and on-this-page rail.
  - `CommunityPage` — patterned community hero, three contribution cards, DrupalCon promo band.

## Interactions
Header pills route between screens; module names open the project page; the module filter and project tabs are live.

## Fidelity notes
Copy (nav labels, product descriptions, stats) is verbatim from drupal.org / new.drupal.org. Layout is
brand-system-derived: the production theme CSS and the Figma redesign file were both unreachable, so treat
this as an on-brand reconstruction rather than a pixel recreation.

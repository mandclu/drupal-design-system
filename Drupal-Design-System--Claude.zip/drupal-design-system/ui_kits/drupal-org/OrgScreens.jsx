const DS=window.DrupalDesignSystem_e0f3ad;
const A='../../assets';

function OrgHome({go}){
  const {Button,Card,Badge,GuiBlock,StatBlock,PatternPanel,Icon}=DS;
  return (<>
    <PatternPanel pattern="grey-light" background="var(--surface-page)" basePath={A+'/png/patterns'} size="cover" opacity={.55}>
      <div className="wrap" style={{display:'grid',gridTemplateColumns:'1.1fr .9fr',gap:48,alignItems:'center',padding:'72px 32px'}}>
        <div style={{display:'flex',flexDirection:'column',gap:20,alignItems:'flex-start'}}>
          <Badge tone="brand">Drupal CMS 2.0 is available</Badge>
          <h1 style={{font:'var(--text-display)',margin:0,maxWidth:'20ch',letterSpacing:'var(--tracking-tight)'}}>
            Build ambitious digital experiences</h1>
          <p style={{font:'var(--text-lead)',margin:0,maxWidth:'48ch'}}>
            Drupal is an open source platform for building amazing digital experiences. It's made by a dedicated community.
            Anyone can use it, and it will always be free.</p>
          <div style={{display:'flex',gap:14}}>
            <Button size="lg" iconRight="arrow-right" onClick={()=>go('browse')}>Get started</Button>
            <Button size="lg" variant="outline" onClick={()=>go('docs')}>Read the docs</Button>
          </div>
        </div>
        <div style={{display:'flex',justifyContent:'center'}}><GuiBlock tone="blue" size={320} radius={54}>
          <span style={{font:'var(--text-h3)'}}>400k+ sites</span></GuiBlock></div>
      </div>
    </PatternPanel>
    <section className="wrap" style={{padding:'var(--section-y-sm) 32px'}}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:24}}>
        {[['Drupal Core','The open source framework behind millions of websites.','box'],
          ['Drupal CMS','Ready-to-use platform for marketing teams, content creators and site builders.','rocket'],
          ['Drupal AI','Open limitless possibilities with Drupal AI.','sparkles']].map(([t,b,ic])=>(
          <Card key={t} padding={28} href="#" linkLabel="Learn more">
            <Icon name={ic} size={30} color="var(--drupal-blue)"/>
            <h3 style={{font:'var(--text-h4)',margin:'12px 0 6px'}}>{t}</h3>
            <p style={{font:'var(--text-body-md)',margin:0}}>{b}</p></Card>))}
      </div>
    </section>
    <section style={{background:'var(--surface-subtle)',padding:'var(--space-16) 0'}}>
      <div className="wrap" style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:24}}>
        {[['400k+','websites using Drupal today'],['70%','Top 100 universities use Drupal'],['100+','Drupal Certified Partners'],['150+','countries use Drupal']]
          .map(([v,l])=><StatBlock key={v} value={v} label={l}/>)}
      </div>
    </section>
    <section className="wrap" style={{padding:'var(--section-y-sm) 32px'}}>
      <div style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',marginBottom:24}}>
        <h2 style={{font:'var(--text-h2)',margin:0}}>News & blogs</h2><a href="#">All news</a></div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:24}}>
        {[['Drupal CMS 2.0 is here: visual building, AI and site templates','Release','var(--gradient-navy-blue)'],
          ['DrupalCon Europe 2026 lands in Rotterdam','Events','var(--gradient-red-yellow)'],
          ['The 2026 Drupal Business Survey is open','Association','var(--gradient-purple-blue)']].map(([t,tag,g])=>(
          <Card key={t} eyebrow={tag} title={t} href="#" linkLabel="Read the post"
            media={<div style={{height:'100%',background:g}}/>}/>))}
      </div>
    </section>
  </>);
}

function BrowseModules({go}){
  const {Tabs,Input,Select,Tag,Card,Badge,Button,Icon,Checkbox}=DS;
  const all=[['Views Bulk Operations','Adds an "Action" dropdown to Views for bulk operations on selected rows.',['Site building','Views'],'42,318'],
    ['Metatag','Automatically provide structured metadata, aka meta tags, about your website.',['SEO'],'318,204'],
    ['Paragraphs','Create flexible, structured content with reusable paragraph types.',['Content','Site building'],'271,553'],
    ['Webform','Build any type of form, from a simple contact form to complex multi-step workflows.',['Forms'],'404,127'],
    ['Search API','Provides a generic framework for modular search implementations.',['Search'],'188,940'],
    ['AI Agents','Agentic AI building blocks for Drupal CMS site building tasks.',['AI','Experimental'],'6,412']];
  const [q,setQ]=React.useState('');
  const [tab,setTab]=React.useState('Modules');
  const list=all.filter(m=>m[0].toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="wrap" style={{padding:'40px 32px'}}>
      <h1 style={{font:'var(--text-h1)',margin:'0 0 8px'}}>Download & Extend</h1>
      <p style={{font:'var(--text-lead)',margin:'0 0 24px'}}>Extend your project's functionality with 50,000+ community modules, themes and recipes.</p>
      <Tabs variant="pill" items={['Modules','Themes','Recipes','Site templates','Distributions']} value={tab} onChange={setTab} style={{marginBottom:28}}/>
      <div style={{display:'grid',gridTemplateColumns:'260px 1fr',gap:32,alignItems:'start'}}>
        <aside style={{display:'flex',flexDirection:'column',gap:20,border:'1px solid var(--border-subtle)',
          borderRadius:'var(--radius-lg)',padding:24}}>
          <Input iconLeft="search" placeholder="Filter by name" value={q} onChange={e=>setQ(e.target.value)} aria-label="Filter modules"/>
          <Select label="Core compatibility" options={['Drupal 11','Drupal 10','Drupal 7']}/>
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            <span style={{font:'var(--text-label)'}}>Status</span>
            <Checkbox label="Stable releases" defaultChecked/>
            <Checkbox label="Security covered" defaultChecked/>
            <Checkbox label="Experimental"/>
          </div>
          <div style={{display:'flex',flexWrap:'wrap',gap:8}}>
            {['SEO','Content','Views','AI','Forms'].map(t=><Tag key={t} onClick={()=>{}}>{t}</Tag>)}
          </div>
        </aside>
        <div style={{display:'flex',flexDirection:'column',gap:16}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <span style={{font:'var(--text-body-sm)',color:'var(--text-muted)'}}>{list.length} of 50,214 {tab.toLowerCase()}</span>
            <Select options={['Most installed','Recently updated','A–Z']} style={{width:200}}/>
          </div>
          {list.map(([n,d,tags,installs])=>(
            <div key={n} style={{display:'flex',gap:20,alignItems:'flex-start',border:'1px solid var(--border-subtle)',
              borderRadius:'var(--radius-md)',padding:'20px 24px',background:'var(--surface-card)'}}>
              <div style={{width:44,height:44,borderRadius:'var(--radius-sm)',background:'var(--surface-accent-tint)',
                display:'flex',alignItems:'center',justifyContent:'center',flex:'0 0 auto'}}>
                <Icon name="package" size={22} color="var(--drupal-blue)"/></div>
              <div style={{flex:1}}>
                <button onClick={()=>go('project')} style={{border:0,background:'transparent',padding:0,cursor:'pointer',
                  font:'var(--text-h4)',color:'var(--text-link)'}}>{n}</button>
                <p style={{font:'var(--text-body-md)',margin:'6px 0 10px'}}>{d}</p>
                <div style={{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}}>
                  {tags.map(t=><Badge key={t} tone="neutral" uppercase={false}>{t}</Badge>)}
                  <span style={{font:'var(--text-body-sm)',color:'var(--text-muted)'}}>{installs} sites</span></div>
              </div>
              <Button size="sm" variant="outline">Install</Button>
            </div>))}
        </div>
      </div>
    </div>
  );
}

function ProjectPage({go}){
  const {Breadcrumbs,Badge,Button,Tabs,Card,Icon,Tooltip,IconButton}=DS;
  const [tab,setTab]=React.useState('Overview');
  return (
    <div className="wrap" style={{padding:'28px 32px'}}>
      <Breadcrumbs items={[{label:'Drupal.org',href:'#'},{label:'Download & Extend',href:'#'},{label:'Metatag'}]} style={{marginBottom:20}}/>
      <div style={{display:'grid',gridTemplateColumns:'1fr 320px',gap:40,alignItems:'start'}}>
        <div>
          <div style={{display:'flex',gap:14,alignItems:'center',flexWrap:'wrap'}}>
            <h1 style={{font:'var(--text-h1)',margin:0}}>Metatag</h1>
            <Badge tone="brand">Security covered</Badge><Badge tone="neutral" uppercase={false}>Drupal 11 · Drupal 10</Badge></div>
          <p style={{font:'var(--text-lead)',margin:'12px 0 24px',maxWidth:'62ch'}}>
            Automatically provide structured metadata, aka meta tags, about your website. In the context of search engine
            optimization, this module gives you fine-grained control over the meta tags output for every page.</p>
          <Tabs items={['Overview','Releases','Issues','Documentation','Automated testing']} value={tab} onChange={setTab} style={{marginBottom:24}}/>
          {tab==='Releases'?(
            <div style={{display:'flex',flexDirection:'column',gap:12}}>
              {[['2.1.0','Recommended','11 Aug 2026'],['2.0.3','Also available','2 Mar 2026'],['1.26.0','Legacy','14 Sep 2024']].map(([v,s,d])=>(
                <div key={v} style={{display:'flex',alignItems:'center',gap:16,border:'1px solid var(--border-subtle)',
                  borderRadius:'var(--radius-md)',padding:'16px 20px'}}>
                  <span style={{font:'var(--text-h4)',minWidth:80}}>{v}</span>
                  <Badge tone={s==='Recommended'?'brand':'neutral'} uppercase={false}>{s}</Badge>
                  <span style={{font:'var(--text-body-sm)',color:'var(--text-muted)',flex:1}}>{d}</span>
                  <Button size="sm" variant="ghost" iconLeft="download">tar.gz</Button></div>))}
            </div>
          ):tab==='Issues'?(
            <div style={{display:'flex',flexDirection:'column',gap:10}}>
              {[['Support for Drupal 11.4','Active','Task','Normal'],['Meta tags missing on taxonomy pages','Needs review','Bug report','Major'],['Add JSON-LD output option','Needs work','Feature request','Normal']]
                .map(([t,s,k,p])=>(
                <div key={t} style={{display:'flex',gap:16,alignItems:'center',padding:'14px 0',borderBottom:'1px solid var(--border-subtle)'}}>
                  <Icon name="circle-dot" size={18} color="var(--drupal-blue)"/>
                  <a href="#" style={{flex:1,font:'var(--text-body-md)'}}>{t}</a>
                  <Badge tone="neutral" uppercase={false}>{k}</Badge>
                  <span style={{font:'var(--text-body-sm)',color:'var(--text-muted)',width:100}}>{s}</span>
                  <span style={{font:'var(--text-body-sm)',color:'var(--text-muted)',width:60}}>{p}</span></div>))}
            </div>
          ):(
            <div style={{display:'flex',flexDirection:'column',gap:16}}>
              <h2 style={{font:'var(--text-h3)',margin:0}}>What it does</h2>
              <p style={{font:'var(--text-body-md)',margin:0,maxWidth:'70ch'}}>
                Metatag adds a configurable set of meta tags to every content type, view and entity on your site: page title,
                description, canonical URL, Open Graph, Twitter cards, Dublin Core and more. Defaults cascade from global
                configuration down to individual entities, so editors only override what they need.</p>
              <h3 style={{font:'var(--text-h4)',margin:'8px 0 0'}}>Install with Composer</h3>
              <pre style={{margin:0,padding:'16px 20px',background:'var(--drupal-navy)',color:'var(--blue-pale)',
                borderRadius:'var(--radius-md)',font:'var(--text-body-sm)',fontFamily:'var(--font-mono)',overflowX:'auto'}}>
composer require drupal/metatag &amp;&amp; drush en metatag</pre>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20,marginTop:8}}>
                <Card tone="tint" padding={22} title="Recipes" body="Ship Metatag pre-configured through the SEO recipe in Drupal CMS."/>
                <Card tone="tint" padding={22} title="Maintainers" body="Maintained by 4 people with 1,240 commits over 14 years."/></div>
            </div>)}
        </div>
        <aside style={{display:'flex',flexDirection:'column',gap:16,border:'1px solid var(--border-subtle)',
          borderRadius:'var(--radius-lg)',padding:24,background:'var(--surface-card)'}}>
          <Button fullWidth iconLeft="download">Download 2.1.0</Button>
          <Button fullWidth variant="outline" onClick={()=>go('docs')}>Read documentation</Button>
          <div style={{display:'flex',gap:8}}>
            <Tooltip label="Copy install command"><IconButton icon="copy" label="Copy install command" variant="outline"/></Tooltip>
            <Tooltip label="Star this project"><IconButton icon="star" label="Star project" variant="outline"/></Tooltip>
            <Tooltip label="Report an issue"><IconButton icon="bug" label="Report an issue" variant="outline"/></Tooltip>
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:8,paddingTop:8,borderTop:'1px solid var(--border-subtle)'}}>
            {[['Reported installs','318,204 sites'],['Downloads','12.4M'],['Last release','11 Aug 2026'],['Open issues','86 of 3,214'],['Maintenance','Actively maintained']]
              .map(([k,v])=>(<div key={k} style={{display:'flex',justifyContent:'space-between',gap:12,font:'var(--text-body-sm)'}}>
                <span style={{color:'var(--text-muted)'}}>{k}</span><span style={{color:'var(--text-strong)'}}>{v}</span></div>))}
          </div>
        </aside>
      </div>
    </div>
  );
}

function DocsPage(){
  const {Breadcrumbs,Tag,Icon,Card}=DS;
  const toc=['What is a recipe?','Applying a recipe','Writing your own','Recipe reference','Troubleshooting'];
  return (
    <div className="wrap" style={{padding:'28px 32px'}}>
      <Breadcrumbs items={[{label:'Documentation',href:'#'},{label:'Drupal CMS',href:'#'},{label:'Recipes'}]} style={{marginBottom:24}}/>
      <div style={{display:'grid',gridTemplateColumns:'240px 1fr 220px',gap:40,alignItems:'start'}}>
        <nav style={{display:'flex',flexDirection:'column',gap:6}}>
          {['Getting started','Installing Drupal','Drupal CMS','Recipes','Site templates','Theming','Upgrading'].map((s,i)=>(
            <a key={s} href="#" style={{font:'var(--text-body-md)',padding:'8px 12px',borderRadius:'var(--radius-sm)',
              textDecoration:'none',background:i===3?'var(--surface-accent-tint)':'transparent',
              color:i===3?'var(--drupal-navy)':'var(--text-link)'}}>{s}</a>))}
        </nav>
        <article style={{maxWidth:'70ch'}}>
          <h1 style={{font:'var(--text-h1)',margin:'0 0 12px'}}>Recipes</h1>
          <p style={{font:'var(--text-lead)',margin:'0 0 24px'}}>
            Recipes are pre-configured packages of modules, configuration and content that enable ambitious site builders
            to set up customized, performant websites quickly.</p>
          <h2 style={{font:'var(--text-h3)',margin:'32px 0 12px'}}>What is a recipe?</h2>
          <p>A recipe is a directory containing a <code style={{fontFamily:'var(--font-mono)',background:'var(--surface-subtle)',padding:'2px 6px',borderRadius:4}}>recipe.yml</code> file
            plus optional configuration and content. Applying a recipe installs the modules it depends on, imports its configuration,
            and creates any default content — then gets out of the way. Recipes are not a dependency: once applied, your site owns the result.</p>
          <h2 style={{font:'var(--text-h3)',margin:'32px 0 12px'}}>Applying a recipe</h2>
          <pre style={{margin:'0 0 20px',padding:'16px 20px',background:'var(--drupal-navy)',color:'var(--blue-pale)',
            borderRadius:'var(--radius-md)',font:'var(--text-body-sm)',fontFamily:'var(--font-mono)',overflowX:'auto'}}>
php core/scripts/drupal recipe recipes/seo_basic</pre>
          <div style={{display:'flex',gap:12,alignItems:'flex-start',padding:'18px 20px',borderRadius:'var(--radius-md)',
            background:'var(--surface-accent-tint)',marginBottom:24}}>
            <Icon name="info" size={20} color="var(--drupal-blue)" style={{marginTop:2}}/>
            <p style={{margin:0,font:'var(--text-body-md)'}}>Recipes are applied once. To keep changes reversible, apply them on a
              development site first and export the resulting configuration.</p></div>
          <div style={{display:'flex',gap:8,flexWrap:'wrap',marginTop:32}}>
            {['Recipes','Site building','Drupal CMS','Configuration'].map(t=><Tag key={t}>{t}</Tag>)}</div>
        </article>
        <aside style={{display:'flex',flexDirection:'column',gap:10,position:'sticky',top:24}}>
          <span style={{font:'var(--text-eyebrow)',letterSpacing:'var(--tracking-caps)',textTransform:'uppercase',color:'var(--text-muted)'}}>On this page</span>
          {toc.map((t,i)=><a key={t} href="#" style={{font:'var(--text-body-sm)',textDecoration:'none',
            color:i===0?'var(--drupal-navy)':'var(--text-link)',
            borderLeft:`2px solid ${i===0?'var(--drupal-blue)':'var(--border-subtle)'}`,paddingLeft:12}}>{t}</a>)}
          <Card tone="tint" padding={18} title="Help improve this page" body="Documentation is written by the community." href="#" linkLabel="Edit on Drupal.org" style={{marginTop:16}}/>
        </aside>
      </div>
    </div>
  );
}

function CommunityPage(){
  const {PatternPanel,Card,Button,StatBlock,Badge}=DS;
  return (<>
    <PatternPanel pattern="blue-multiply" background="var(--drupal-navy)" basePath={A+'/png/patterns'} opacity={.5}>
      <div className="wrap" style={{padding:'72px 32px',textAlign:'center'}}>
        <h1 style={{font:'var(--text-display)',color:'var(--drupal-white)',margin:'0 0 12px'}}>Come for the code, stay for the community</h1>
        <p style={{font:'var(--text-lead)',color:'rgba(255,255,255,.85)',maxWidth:'56ch',margin:'0 auto'}}>
          Drupal is made by a dedicated community of developers, marketers, designers and contributors in more than 150 countries.</p>
      </div>
    </PatternPanel>
    <section className="wrap" style={{padding:'var(--section-y-sm) 32px',display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:24}}>
      {[['How to contribute','Get involved in growing and evolving Drupal.'],['Events','Discover local events, community meet-ups, and training.'],['Slack','Get support and communicate with the global Drupal community.']]
        .map(([t,b])=><Card key={t} title={t} body={b} href="#" padding={28}/>)}
    </section>
    <section className="wrap" style={{padding:'0 32px var(--section-y-sm)'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:32,background:'var(--surface-subtle)',
        borderRadius:'var(--radius-xl)',padding:'40px 48px'}}>
        <div><Badge tone="yellow">DrupalCon Europe</Badge>
          <h2 style={{font:'var(--text-h2)',margin:'14px 0 8px'}}>Rotterdam, 28 September – 1 October 2026</h2>
          <p style={{font:'var(--text-body-md)',margin:0,maxWidth:'52ch'}}>DrupalCon unites experts from around the globe who create ambitious digital experiences.</p></div>
        <Button size="lg" iconRight="arrow-right">Learn more</Button></div>
    </section>
  </>);
}
Object.assign(window,{OrgHome,BrowseModules,ProjectPage,DocsPage,CommunityPage});

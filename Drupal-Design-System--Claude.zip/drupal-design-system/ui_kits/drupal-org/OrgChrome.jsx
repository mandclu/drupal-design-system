const DS=window.DrupalDesignSystem_e0f3ad;
const A='../../assets';

function OrgHeader({route,go}){
  const {Logo,Button,Input,Icon}=DS;
  const nav=[['home','Home'],['browse','Modules'],['project','Project'],['docs','Documentation'],['community','Community']];
  return (
    <header style={{background:'var(--drupal-navy)'}}>
      <div className="wrap" style={{display:'flex',alignItems:'center',gap:24,padding:'16px 32px'}}>
        <a href="#" onClick={e=>{e.preventDefault();go('home')}}><Logo variant="drupal-horizontal" color="white" height={28} basePath={A+'/png/logos'}/></a>
        <nav style={{display:'flex',gap:4,flex:1}}>
          {nav.map(([k,l])=>(
            <button key={k} onClick={()=>go(k)} style={{border:0,cursor:'pointer',padding:'8px 14px',borderRadius:'var(--radius-pill)',
              font:'var(--text-label)',background:route===k?'rgba(255,255,255,.14)':'transparent',
              color:route===k?'var(--drupal-white)':'rgba(255,255,255,.8)'}}>{l}</button>))}
        </nav>
        <div style={{width:250}}><Input iconLeft="search" placeholder="Search Drupal.org" aria-label="Search Drupal.org"/></div>
        <Button size="sm" variant="inverse">Log in</Button>
      </div>
    </header>
  );
}

function OrgFooter(){
  const cols=[['News items',['News','Planet Drupal','Social media','Security advisories']],
    ['Our community',['Community','Services & training','Contributor guide','DrupalCon']],
    ['Documentation',['Documentation','Drupal Guide','Developer docs','API.Drupal.org']],
    ['Drupal code base',['Download & Extend','Drupal core','Modules','Themes']]];
  return (
    <footer style={{borderTop:'1px solid var(--border-subtle)',background:'var(--surface-subtle)',marginTop:64}}>
      <div className="wrap" style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:32,padding:'48px 32px'}}>
        {cols.map(([h,items])=>(
          <div key={h} style={{display:'flex',flexDirection:'column',gap:10}}>
            <span style={{font:'var(--text-eyebrow)',letterSpacing:'var(--tracking-caps)',textTransform:'uppercase',color:'var(--text-muted)'}}>{h}</span>
            {items.map(i=><a key={i} href="#" style={{font:'var(--text-body-sm)'}}>{i}</a>)}
          </div>))}
      </div>
      <div className="wrap" style={{padding:'0 32px 40px',font:'var(--text-body-sm)',color:'var(--text-muted)'}}>
        Drupal is a registered trademark of Dries Buytaert. Infrastructure management for Drupal.org provided by Tag1.
      </div>
    </footer>
  );
}
Object.assign(window,{OrgHeader,OrgFooter});

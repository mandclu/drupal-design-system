const DS=window.DrupalDesignSystem_e0f3ad;
const A='../../assets';

function TopBar({onTrial}){
  const {Logo,Button,IconButton,Icon}=DS;
  const [open,setOpen]=React.useState(null);
  const menus={
    'Discover Drupal':[['Drupal Core','The open source framework behind millions of websites'],['Drupal CMS','Drupal CMS puts the power of Drupal into the hands of marketers, designers and content creators'],['Drupal AI','Open limitless possibilities with Drupal AI'],['Case Studies','Powerful stories that show Drupal solutions in the real world']],
    'Build with Drupal':[['Download Drupal','Download Drupal and the extensions you need'],['Documentation','Full knowledgebase including Drupal 7 resources'],['Recipes','Automate module installation and configuration'],['Site Templates','Complete, configured starting points for your Drupal website']],
    'Partners & Services':[['Find a Drupal Certified Partner','Connect with the best Drupal agencies around the world'],['Find a Hosting Provider','Find a hosting provider for your Drupal project'],['Find Training','Upskill your Drupal team']],
    'Community':[['About the Community','Come for the code, stay for the community'],['DrupalCon','Network, learn, and be inspired'],['Events','Discover local events, meet-ups, and training'],['Slack','Get support and communicate with the global Drupal community']]
  };
  return (
    <header style={{position:'sticky',top:0,zIndex:30,background:'var(--surface-page)',borderBottom:'1px solid var(--border-subtle)'}}
      onMouseLeave={()=>setOpen(null)}>
      <div className="wrap" style={{display:'flex',alignItems:'center',gap:32,height:76}}>
        <Logo variant="drupal-horizontal" color="navy" height={30} basePath={A+'/png/logos'}/>
        <nav style={{display:'flex',gap:6,flex:1}}>
          {Object.keys(menus).map(m=>(
            <button key={m} onMouseEnter={()=>setOpen(m)} onClick={()=>setOpen(open===m?null:m)}
              style={{display:'inline-flex',alignItems:'center',gap:6,border:0,background:'transparent',cursor:'pointer',
                padding:'8px 12px',borderRadius:'var(--radius-sm)',font:'var(--text-label)',
                color:open===m?'var(--drupal-blue)':'var(--drupal-navy)'}}>
              {m}<Icon name="chevron-down" size={14}/></button>))}
        </nav>
        <IconButton icon="search" label="Search"/>
        <a href="#" style={{font:'var(--text-label)',color:'var(--drupal-navy)',textDecoration:'none'}}>Log in</a>
        <Button size="sm" onClick={onTrial}>Try Drupal CMS</Button>
      </div>
      {open&&(
        <div style={{position:'absolute',left:0,right:0,background:'var(--surface-page)',borderTop:'1px solid var(--border-subtle)',
          borderBottom:'1px solid var(--border-subtle)',boxShadow:'var(--shadow-md)'}}>
          <div className="wrap" style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:24,padding:'28px 32px 32px'}}>
            {menus[open].map(([t,d])=>(
              <a key={t} href="#" style={{textDecoration:'none',display:'flex',flexDirection:'column',gap:4}}>
                <span style={{font:'var(--text-label)',color:'var(--drupal-blue)'}}>{t}</span>
                <span style={{font:'var(--text-body-sm)',color:'var(--text-muted)'}}>{d}</span></a>))}
          </div>
        </div>)}
    </header>
  );
}

function SiteFooter(){
  const {Logo}=DS;
  const cols=[['Drupal',['About Drupal','Code of Conduct','News','Planet Drupal']],
    ['Build',['Download','Documentation','Modules','Recipes']],
    ['Community',['Events','DrupalCon','Slack','Forum']],
    ['Association',['Donate','Become a member','Certified Partners','Sustaining members']]];
  return (
    <footer style={{background:'var(--drupal-navy)',color:'var(--text-inverse)',marginTop:'var(--space-24)'}}>
      <div className="wrap" style={{padding:'64px 32px 40px',display:'grid',gridTemplateColumns:'1.4fr repeat(4,1fr)',gap:32}}>
        <div style={{display:'flex',flexDirection:'column',gap:16}}>
          <Logo variant="drupal-horizontal" color="white" height={30} basePath={A+'/png/logos'}/>
          <p style={{font:'var(--text-body-sm)',color:'rgba(255,255,255,.72)',maxWidth:'34ch',margin:0}}>
            Drupal is an open source platform for building amazing digital experiences. It's made by a dedicated community.
            Anyone can use it, and it will always be free.</p>
        </div>
        {cols.map(([h,items])=>(
          <div key={h} style={{display:'flex',flexDirection:'column',gap:10}}>
            <span style={{font:'var(--text-eyebrow)',letterSpacing:'var(--tracking-caps)',textTransform:'uppercase',color:'var(--blue-pale)'}}>{h}</span>
            {items.map(i=><a key={i} href="#" style={{font:'var(--text-body-sm)',color:'rgba(255,255,255,.86)',textDecoration:'none'}}>{i}</a>)}
          </div>))}
      </div>
      <div className="wrap" style={{padding:'20px 32px 40px',borderTop:'1px solid var(--border-inverse)',display:'flex',justifyContent:'space-between',gap:16}}>
        <span style={{font:'var(--text-body-sm)',color:'rgba(255,255,255,.6)'}}>Drupal is a registered trademark of Dries Buytaert.</span>
        <span style={{font:'var(--text-body-sm)',color:'rgba(255,255,255,.6)'}}>Copyright 2026</span>
      </div>
    </footer>
  );
}
Object.assign(window,{TopBar,SiteFooter});

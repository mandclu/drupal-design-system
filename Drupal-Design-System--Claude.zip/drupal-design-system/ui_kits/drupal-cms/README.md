# UI kit — Drupal CMS marketing site

Recreation of `new.drupal.org/drupal-cms` (the new-brand rollout of Drupal.org), built from the page's
real content and the brand-portal assets.

## Screens / surfaces
- `SiteChrome.jsx` — `TopBar` (sticky header with hover mega-menu, search, log in, trial CTA) and `SiteFooter` (navy, four link columns, trademark line).
- `Sections.jsx` — `Hero`, `ReleaseBand` (Drupal CMS 2.0), `WhyGrid` (four value cards), `FeatureTabs` (six out-of-the-box features, pill tabs), `CaseStudies` (two customer stories with stat pairs), `GetStarted` (CMS vs core comparison + proof-stat band).
- `index.html` — the whole page, click-through: mega-menu opens on hover, feature tabs switch, every CTA opens the trial dialog, submitting shows a success toast.

## Interactions
Hover a top-nav item → mega menu. Click a feature pill → panel swaps. "Try Drupal CMS" (header, hero, get-started) → modal with email/site-name fields → success toast.

## Fidelity notes
Copy is verbatim from the live page. Layout, spacing and type are derived from the brand system, **not**
from the production CSS or Figma file — neither was reachable when this kit was built. Product screenshots
and feature illustrations are marked slots, not fabricated imagery.

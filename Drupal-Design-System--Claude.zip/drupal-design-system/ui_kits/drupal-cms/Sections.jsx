const DS=window.DrupalDesignSystem_e0f3ad;
const A='../../assets';

function Hero({onTrial}){
  const {Button,Badge,GuiBlock,PatternPanel,Logo}=DS;
  return (
    <PatternPanel pattern="tint-lines" background="var(--surface-page)" basePath={A+'/png/patterns'} size="cover" opacity={.5}>
      <div className="wrap" style={{display:'grid',gridTemplateColumns:'1.05fr .95fr',gap:56,alignItems:'center',padding:'80px 32px 88px'}}>
        <div style={{display:'flex',flexDirection:'column',alignItems:'flex-start',gap:24}}>
          <Logo variant="cms-horizontal" color="blue" height={44} basePath={A+'/png/logos'}/>
          <h1 style={{font:'var(--text-display)',color:'var(--drupal-navy)',letterSpacing:'var(--tracking-tight)',margin:0,maxWidth:'18ch'}}>
            Your Launchpad for Limitless Marketing Possibilities</h1>
          <p style={{font:'var(--text-lead)',color:'var(--text-body)',maxWidth:'46ch',margin:0}}>
            Drupal CMS puts the power of Drupal into the hands of marketers, designers and content creators.</p>
          <div style={{display:'flex',gap:14,flexWrap:'wrap'}}>
            <Button size="lg" iconRight="arrow-right" onClick={onTrial}>Try Drupal CMS 2.0</Button>
            <Button size="lg" variant="outline" href="#download">Download & Build</Button>
          </div>
          <Badge tone="yellow">Free and open source, always</Badge>
        </div>
        <div style={{display:'flex',justifyContent:'center'}}>
          <GuiBlock tone="yellow" size={380} radius={64}>
            <span style={{font:'var(--text-h3)',display:'block',maxWidth:'14ch'}}>Drupal Canvas visual page building</span>
          </GuiBlock>
        </div>
      </div>
    </PatternPanel>
  );
}

function ReleaseBand(){
  const {Card,Button,Badge}=DS;
  const points=['Visual page building with Drupal Canvas','Site templates install in under 3 minutes','One-click marketing integrations','Optional AI tools with governance','26-33% faster performance'];
  const {Icon}=DS;
  return (
    <section style={{background:'var(--drupal-navy)',color:'var(--text-inverse)',padding:'var(--space-20) 0'}}>
      <div className="wrap" style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:56,alignItems:'center'}}>
        <div style={{display:'flex',flexDirection:'column',gap:20,alignItems:'flex-start'}}>
          <Badge tone="yellow">New release</Badge>
          <h2 style={{font:'var(--text-h1)',color:'var(--drupal-white)',margin:0}}>Drupal CMS 2.0 is Here</h2>
          <ul style={{listStyle:'none',padding:0,margin:0,display:'flex',flexDirection:'column',gap:12}}>
            {points.map(p=>(<li key={p} style={{display:'flex',gap:12,alignItems:'flex-start',font:'var(--text-body-md)',color:'rgba(255,255,255,.88)'}}>
              <Icon name="check" size={20} color="var(--yellow)" style={{marginTop:3}}/>{p}</li>))}
          </ul>
          <div style={{display:'flex',gap:14,flexWrap:'wrap',marginTop:8}}>
            <Button variant="inverse" iconRight="arrow-right">Try it now</Button>
            <Button variant="ghost" style={{color:'var(--blue-pale)'}}>Read more about 2.0</Button>
          </div>
        </div>
        <div style={{borderRadius:'var(--radius-lg)',overflow:'hidden',border:'1px solid var(--border-inverse)',background:'var(--navy-alt)'}}>
          <div style={{display:'flex',gap:8,padding:'14px 16px',borderBottom:'1px solid var(--border-inverse)'}}>
            {['var(--coral)','var(--yellow)','var(--drupal-blue)'].map(c=><span key={c} style={{width:11,height:11,borderRadius:'50%',background:c}}/>)}
          </div>
          <div style={{height:300,background:'var(--gradient-navy-blue)',display:'flex',alignItems:'center',justifyContent:'center',
            font:'var(--text-body-sm)',color:'rgba(255,255,255,.8)',textAlign:'center',padding:24}}>
            Product screenshot slot — drop a Drupal Canvas capture here</div>
        </div>
      </div>
    </section>
  );
}

function WhyGrid(){
  const {Card}=DS;
  const items=[['Lightning fast launch','Smart defaults and pre-built recipes get you from idea to live site faster than ever.','zap'],
    ['Built for marketers','Intuitive drag-and-drop tools, visual page building, and marketer-friendly interfaces designed with your workflow in mind.','wand-2'],
    ['Build without limits','From startup to enterprise, Drupal CMS grows with you. Handle millions of visitors, thousands of pages, and complex integrations effortlessly.','trending-up'],
    ['Powerful & open','As an accessible, secure open source platform, it checks all the boxes for your IT team. Your content, your data, your choice.','shield-check']];
  const {Icon}=DS;
  return (
    <section style={{padding:'var(--section-y) 0'}}>
      <div className="wrap">
        <h2 style={{font:'var(--text-h1)',margin:'0 0 40px',maxWidth:'24ch'}}>Why Ambitious Marketers Choose Drupal CMS</h2>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:24}}>
          {items.map(([t,b,ic])=>(
            <Card key={t} tone="tint" padding={28}>
              <Icon name={ic} size={32} color="var(--drupal-blue)"/>
              <h3 style={{font:'var(--text-h4)',margin:'12px 0 6px'}}>{t}</h3>
              <p style={{font:'var(--text-body-md)',margin:0}}>{b}</p>
            </Card>))}
        </div>
      </div>
    </section>
  );
}

function FeatureTabs(){
  const {Tabs,Icon,Button}=DS;
  const features={
    'Quick setup':['Quick setup, easy admin','Launch your site quickly with tools designed for marketing teams, then manage it effortlessly with intuitive admin tools and automated processes—no technical expertise required.','settings'],
    'Marketing':['Marketing launchpad','Ready-to-use content types and intelligent workflows help you build engaging digital experiences faster.','megaphone'],
    'AI':['AI-powered building','Let AI handle the complex technical setup while you focus on creating content that converts visitors into customers.','sparkles'],
    'Content':['Better content tools','Empower your team with user-friendly content creation tools designed specifically for marketers and content creators.','file-text'],
    'Media':['Media integration','Manage images, videos, and documents effortlessly with powerful built-in media tools and automated optimization.','image'],
    'Privacy':['Privacy compliance','GDPR, CCPA, and other privacy regulations handled automatically so you can focus on content, not compliance.','lock']
  };
  const [tab,setTab]=React.useState('Quick setup');
  const [title,body,icon]=features[tab];
  return (
    <section style={{padding:'0 0 var(--section-y)'}}>
      <div className="wrap">
        <h2 style={{font:'var(--text-h1)',margin:'0 0 28px'}}>Everything you need out-of-the-box</h2>
        <Tabs variant="pill" items={Object.keys(features)} value={tab} onChange={setTab} style={{marginBottom:32}}/>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:48,alignItems:'center',
          background:'var(--surface-subtle)',borderRadius:'var(--radius-xl)',padding:48}}>
          <div>
            <Icon name={icon} size={36} color="var(--drupal-blue)"/>
            <h3 style={{font:'var(--text-h2)',margin:'16px 0 12px'}}>{title}</h3>
            <p style={{font:'var(--text-lead)',margin:'0 0 20px',maxWidth:'42ch'}}>{body}</p>
            <Button variant="ghost" iconRight="arrow-right">Explore this feature</Button>
          </div>
          <div style={{aspectRatio:'4/3',borderRadius:'var(--radius-lg)',background:'var(--gradient-yellow-light-blue)',
            display:'flex',alignItems:'flex-end',padding:24,font:'var(--text-body-sm)',color:'var(--drupal-navy)'}}>
            Feature illustration slot — {tab}</div>
        </div>
      </div>
    </section>
  );
}

function CaseStudies(){
  const {StatBlock,Button,Badge}=DS;
  const studies=[['From WordPress Worries to Drupal CMS Confidence','SpecBee migrated DamFailures.org from WordPress to Drupal CMS, delivering an 88% performance boost and user-friendly content management that made their small non-technical team\'s work effortless.',[['88%','improvement in performance scores'],['6','week redesign & migration']],'var(--gradient-red-yellow)'],
    ['Digital impact in 8 weeks with Drupal CMS','Find out how Drupal CMS and Elevated Third helped Defend Public Health launch their mission-critical site lightning fast.',[['3,604','visitors in 3 weeks'],['269','new email subscribers']],'var(--gradient-purple-blue)']];
  return (
    <section style={{padding:'0 0 var(--section-y)'}}>
      <div className="wrap" style={{display:'flex',flexDirection:'column',gap:32}}>
        {studies.map(([t,b,stats,grad],i)=>(
          <article key={t} style={{display:'grid',gridTemplateColumns:i%2?'1fr 1.1fr':'1.1fr 1fr',gap:40,alignItems:'center',
            border:'1px solid var(--border-subtle)',borderRadius:'var(--radius-xl)',overflow:'hidden',background:'var(--surface-card)'}}>
            <div style={{padding:40,order:i%2?2:1}}>
              <Badge tone="lavender" uppercase={false}>Case study</Badge>
              <h3 style={{font:'var(--text-h2)',margin:'16px 0 12px'}}>{t}</h3>
              <p style={{font:'var(--text-body-md)',margin:'0 0 24px',maxWidth:'52ch'}}>{b}</p>
              <div style={{display:'flex',gap:48,marginBottom:24}}>
                {stats.map(([v,l])=><StatBlock key={v} value={v} label={l}/>)}
              </div>
              <Button variant="outline" iconRight="arrow-right">Learn more</Button>
            </div>
            <div style={{order:i%2?1:2,alignSelf:'stretch',minHeight:320,background:grad,display:'flex',alignItems:'flex-end',
              padding:24,font:'var(--text-body-sm)',color:'var(--drupal-navy)'}}>Customer site screenshot slot</div>
          </article>))}
      </div>
    </section>
  );
}

function GetStarted({onTrial}){
  const {Card,Button,Badge,StatBlock,Icon,PatternPanel}=DS;
  return (
    <>
    <section style={{padding:'0 0 var(--section-y)'}}>
      <div className="wrap">
        <h2 style={{font:'var(--text-h1)',margin:'0 0 8px'}}>Get started with Drupal</h2>
        <p style={{font:'var(--text-lead)',margin:'0 0 36px'}}>Discover the power of Drupal and start creating exceptional digital experiences.</p>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:24}}>
          {[['Drupal CMS','Recommended for most websites',['For marketers, content creators and site builders','Enterprise-grade quality in a CMS that\'s easy to use','Smart defaults to start quickly','Enhanced user-experience to guide you through setup'],'Try Drupal CMS now',true],
            ['Drupal core','For advanced users and developers',['Provides the building blocks for your digital experience','Start from scratch and customize around your vision','Make your own decisions around included features'],'Build with Drupal core',false]]
            .map(([t,sub,items,cta,primary])=>(
            <div key={t} style={{border:`2px solid ${primary?'var(--drupal-blue)':'var(--border-subtle)'}`,borderRadius:'var(--radius-lg)',padding:32,
              display:'flex',flexDirection:'column',gap:14,background:'var(--surface-card)'}}>
              {primary&&<Badge tone="brand">Now available</Badge>}
              <h3 style={{font:'var(--text-h2)',margin:0}}>{t}</h3>
              <p style={{font:'var(--text-body-md)',color:'var(--text-muted)',margin:0}}>{sub}</p>
              <ul style={{listStyle:'none',padding:0,margin:'8px 0 16px',display:'flex',flexDirection:'column',gap:10}}>
                {items.map(i=><li key={i} style={{display:'flex',gap:10,font:'var(--text-body-md)'}}>
                  <Icon name="check" size={18} color="var(--drupal-blue)" style={{marginTop:3}}/>{i}</li>)}
              </ul>
              <Button variant={primary?'primary':'outline'} onClick={primary?onTrial:undefined} style={{marginTop:'auto',alignSelf:'flex-start'}}>{cta}</Button>
            </div>))}
        </div>
      </div>
    </section>
    <PatternPanel pattern="blue-dense" background="var(--drupal-navy)" basePath={A+'/png/patterns'} opacity={.45} size="cover">
      <div className="wrap" style={{padding:'var(--space-20) 32px',textAlign:'center'}}>
        <h2 style={{font:'var(--text-h1)',color:'var(--drupal-white)',margin:'0 0 12px'}}>Trusted by the world's biggest brands</h2>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:32,marginTop:40}}>
          {[['400k+','websites using Drupal today'],['70%','Top 100 universities use Drupal'],['100+','Drupal Certified Partners provide global support'],['150+','Countries use Drupal']]
            .map(([v,l])=><StatBlock key={v} value={v} label={l} tone="inverse" align="center"/>)}
        </div>
      </div>
    </PatternPanel>
    </>
  );
}
Object.assign(window,{Hero,ReleaseBand,WhyGrid,FeatureTabs,CaseStudies,GetStarted});

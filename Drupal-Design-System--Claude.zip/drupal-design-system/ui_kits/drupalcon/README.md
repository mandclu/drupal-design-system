# UI kit — DrupalCon / Drupal Events

Recreation of the events.drupal.org surfaces, on the new Drupal brand.

## Screens
- `EventHeader` — drop mark + "Drupal Events", underline route nav, event dateline, register CTA.
- `EventHome` — navy hero with the event tagline, three upcoming-event cards (Rotterdam 2026, Orlando 2027, community events), "What is DrupalCon?" stat band with the three value props, patterned attendee-quote band.
- `ProgramPage` — four day tabs, track filter chips, session rows with time / room / track badge, BoF and Contribution Day sidebar cards.
- `RegisterPage` — three selectable ticket tiers, attendee form, Code-of-Conduct checkbox, sticky order summary, success toast.
- `EventFooter` — policies / contact / connect / community columns and the Association credit line.

## Interactions
Route nav and register CTAs switch screens; day tabs and track chips filter the schedule live; ticket tier drives the order summary; "Continue to payment" fires a toast.

## Fidelity notes
Event names, dates, taglines and stats come from events.drupal.org. The live DrupalCon theme has its own
event-specific art direction (city photography, per-event logo); that artwork was not available, so this kit
renders the same structure using the core brand palette, patterns and GUI blocks. Session titles are plausible
placeholders — the 2026 program was not published at build time.

const DS=window.DrupalDesignSystem_e0f3ad;
const A='../../assets';

function EventHeader({route,go,onRegister}){
  const {Logo,Button}=DS;
  const nav=[['home','Home'],['program','Program'],['register','Register']];
  return (
    <header style={{borderBottom:'1px solid var(--border-subtle)',background:'var(--surface-page)',position:'sticky',top:0,zIndex:30}}>
      <div className="wrap" style={{display:'flex',alignItems:'center',gap:28,height:72}}>
        <a href="#" onClick={e=>{e.preventDefault();go('home')}} style={{display:'flex',alignItems:'center',gap:12,textDecoration:'none'}}>
          <Logo variant="drop" color="blue" height={30} basePath={A+'/png/logos'}/>
          <span style={{font:'var(--text-h4)',color:'var(--drupal-navy)'}}>Drupal Events</span></a>
        <nav style={{display:'flex',gap:22,flex:1,marginLeft:12}}>
          {nav.map(([k,l])=>(
            <button key={k} onClick={()=>go(k)} style={{border:0,background:'transparent',cursor:'pointer',font:'var(--text-label)',
              padding:'6px 0',color:route===k?'var(--drupal-blue)':'var(--drupal-navy)',
              boxShadow:route===k?'inset 0 -3px 0 0 var(--drupal-blue)':'none'}}>{l}</button>))}
        </nav>
        <span style={{font:'var(--text-body-sm)',color:'var(--text-muted)'}}>Rotterdam · 28 Sep – 1 Oct 2026</span>
        <Button size="sm" onClick={onRegister}>Register</Button>
      </div>
    </header>
  );
}

function EventHome({go,onRegister}){
  const {Button,Badge,Card,StatBlock,PatternPanel,GuiBlock,Icon}=DS;
  return (<>
    <section style={{background:'var(--drupal-navy)',color:'var(--text-inverse)'}}>
      <div className="wrap" style={{display:'grid',gridTemplateColumns:'1.1fr .9fr',gap:48,alignItems:'center',padding:'80px 32px'}}>
        <div style={{display:'flex',flexDirection:'column',gap:20,alignItems:'flex-start'}}>
          <Badge tone="yellow">DrupalCon Europe 2026</Badge>
          <h1 style={{font:'var(--text-display)',color:'var(--drupal-white)',margin:0,maxWidth:'20ch',letterSpacing:'var(--tracking-tight)'}}>
            Where the art of the possible comes to life.</h1>
          <p style={{font:'var(--text-lead)',color:'rgba(255,255,255,.85)',maxWidth:'50ch',margin:0}}>
            DrupalCon unites experts from around the globe who create ambitious digital experiences.
            Network, learn, and be inspired.</p>
          <div style={{display:'flex',gap:14,flexWrap:'wrap'}}>
            <Button size="lg" variant="inverse" onClick={onRegister}>Register now</Button>
            <Button size="lg" variant="ghost" style={{color:'var(--blue-pale)'}} onClick={()=>go('program')}>See the program</Button></div>
        </div>
        <div style={{display:'flex',justifyContent:'center'}}>
          <GuiBlock tone="yellow" size={330} radius={56}><span style={{font:'var(--text-h3)'}}>Rotterdam<br/>28 Sep – 1 Oct</span></GuiBlock></div>
      </div>
    </section>
    <section className="wrap" style={{padding:'var(--section-y-sm) 32px'}}>
      <h2 style={{font:'var(--text-h2)',margin:'0 0 24px'}}>Upcoming events</h2>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:24}}>
        {[['DrupalCon Rotterdam','28 September – 1 October 2026','DrupalCon Europe 2026 lands in Rotterdam! Experience the perfect mix of innovation, creativity, and community in one of Europe\'s most modern and inspiring cities.','var(--gradient-navy-blue)'],
          ['DrupalCon Orlando','22–25 March 2027','Orlando is a city defined by the journey from a simple spark of imagination to a world-class reality. Join a strong local community in a Human Rights Campaign 100 city.','var(--gradient-red-yellow)'],
          ['Community events','All year, worldwide','The Drupal community organizes events all over the globe, both virtually and in-person. Find an event near you, or submit your own.','var(--gradient-purple-blue)']]
          .map(([t,d,b,g])=>(
          <Card key={t} eyebrow={d} title={t} body={b} href="#" linkLabel="Learn more"
            media={<div style={{height:'100%',background:g}}/>}/>))}
      </div>
    </section>
    <section style={{background:'var(--surface-subtle)',padding:'var(--space-16) 0'}}>
      <div className="wrap">
        <h2 style={{font:'var(--text-h3)',margin:'0 0 28px'}}>What is DrupalCon?</h2>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:32}}>
          {[['32','events since 2005'],['3000','attendees on average'],['165','sessions per event']].map(([v,l])=><StatBlock key={v} value={v} label={l}/>)}
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:24,marginTop:40}}>
          {[['Keynotes & Sessions','for leaders, developers, and end users','mic'],
            ['Summits & Training','industry-focused to elevate your skill','graduation-cap'],
            ['Networking & Collaboration','that you can only find at DrupalCon','users']].map(([t,b,ic])=>(
            <div key={t} style={{display:'flex',gap:14,alignItems:'flex-start'}}>
              <Icon name={ic} size={26} color="var(--drupal-blue)" style={{marginTop:3}}/>
              <div><h3 style={{font:'var(--text-h4)',margin:'0 0 4px'}}>{t}</h3>
                <p style={{font:'var(--text-body-md)',margin:0}}>{b}</p></div></div>))}
        </div>
      </div>
    </section>
    <PatternPanel pattern="lavender-mix" background="var(--surface-page)" basePath={A+'/png/patterns'} size="cover" opacity={.7}>
      <div className="wrap" style={{padding:'var(--space-20) 32px'}}>
        <blockquote style={{margin:0,maxWidth:'46ch'}}>
          <p style={{font:'var(--weight-display-semibold) 30px/1.35 var(--font-display)',color:'var(--drupal-navy)',margin:'0 0 16px'}}>
            "Before meeting and working together with people at DrupalCon, they were colleagues, but then I learned so much
            working in person, and they became more like family."</p>
          <footer style={{font:'var(--text-body-sm)',color:'var(--text-body)'}}>Tushar Thatikonda · 2019 Grant Recipient</footer>
        </blockquote>
      </div>
    </PatternPanel>
  </>);
}

function ProgramPage(){
  const {Tabs,Badge,Tag,Card,Icon}=DS;
  const days={'Mon 28 Sep':[['09:00','Registration & coffee','Foyer','Community'],['10:00','Opening keynote: the art of the possible','Main hall','Keynote'],['11:30','Drupal Canvas in production','Room 1','Session'],['13:00','Lunch & Birds of a Feather','Expo','BoF'],['14:30','Governing AI in Drupal CMS','Room 2','Session']],
    'Tue 29 Sep':[['09:30','Driesnote','Main hall','Keynote'],['11:00','Site templates: from install to launch in 3 minutes','Room 1','Session'],['12:30','Higher education summit','Room 4','Summit'],['15:00','Contribution mentoring','Contribution room','Contribution']],
    'Wed 30 Sep':[['09:30','Marketing with Drupal CMS','Room 2','Session'],['11:00','Accessibility clinic','Room 3','Training'],['13:30','Agency leadership panel','Main hall','Panel'],['16:00','Trivia night','Expo','Social']],
    'Thu 1 Oct':[['09:30','Contribution day kick-off','Contribution room','Contribution'],['10:00','Sprints','Contribution room','Contribution'],['15:00','Closing session','Main hall','Keynote']]};
  const [day,setDay]=React.useState('Mon 28 Sep');
  const [track,setTrack]=React.useState('All tracks');
  const tracks=['All tracks','Keynote','Session','Summit','Contribution'];
  const rows=days[day].filter(r=>track==='All tracks'||r[3]===track);
  return (
    <div className="wrap" style={{padding:'40px 32px'}}>
      <h1 style={{font:'var(--text-h1)',margin:'0 0 8px'}}>Program</h1>
      <p style={{font:'var(--text-lead)',margin:'0 0 28px',maxWidth:'56ch'}}>
        Whether you're a C-level, a developer, a content strategist, or a marketer—there's something for you at DrupalCon.</p>
      <Tabs items={Object.keys(days)} value={day} onChange={setDay} style={{marginBottom:20}}/>
      <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:24}}>
        {tracks.map(t=><Tag key={t} selected={t===track} onClick={()=>setTrack(t)}>{t}</Tag>)}</div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:32,alignItems:'start'}}>
        <div style={{display:'flex',flexDirection:'column'}}>
          {rows.map(([time,title,room,tag])=>(
            <div key={title} style={{display:'grid',gridTemplateColumns:'80px 1fr auto',gap:20,alignItems:'center',
              padding:'20px 0',borderBottom:'1px solid var(--border-subtle)'}}>
              <span style={{font:'var(--text-label)',color:'var(--drupal-blue)',fontVariantNumeric:'tabular-nums'}}>{time}</span>
              <div><h3 style={{font:'var(--text-h4)',margin:'0 0 4px'}}>{title}</h3>
                <span style={{display:'inline-flex',gap:6,alignItems:'center',font:'var(--text-body-sm)',color:'var(--text-muted)'}}>
                  <Icon name="map-pin" size={14}/>{room}</span></div>
              <Badge tone={tag==='Keynote'?'navy':tag==='Contribution'?'coral':'tint'} uppercase={false}>{tag}</Badge></div>))}
          {rows.length===0&&<p style={{font:'var(--text-body-md)',color:'var(--text-muted)'}}>No sessions in this track on {day}.</p>}
        </div>
        <aside style={{display:'flex',flexDirection:'column',gap:16}}>
          <Card tone="tint" padding={22} title="Birds of a Feather" body="Informal gatherings of like-minded people who want to discuss a specific topic without an agenda." href="#" linkLabel="Propose a BoF"/>
          <Card tone="navy" padding={22} title="Contribution Day" body="A working meeting focused on the project — a great way to get involved, with mentors on hand." href="#" linkLabel="Join a sprint"/>
        </aside>
      </div>
    </div>
  );
}

function RegisterPage(){
  const {Input,Select,Checkbox,Radio,Button,Badge,Toast,Icon}=DS;
  const [tier,setTier]=React.useState('standard');
  const [sent,setSent]=React.useState(false);
  const tiers=[['early','Early bird','€ 545','Ends 30 June 2026'],['standard','Standard','€ 695','Full four-day access'],['contributor','Contributor','€ 145','For active project contributors']];
  return (
    <div className="wrap" style={{padding:'40px 32px',display:'grid',gridTemplateColumns:'1.15fr .85fr',gap:48,alignItems:'start'}}>
      <div>
        <h1 style={{font:'var(--text-h1)',margin:'0 0 8px'}}>Register for DrupalCon Rotterdam</h1>
        <p style={{font:'var(--text-lead)',margin:'0 0 28px'}}>Four days of keynotes, sessions, summits and contribution — 28 September to 1 October 2026.</p>
        <div style={{display:'flex',flexDirection:'column',gap:12,marginBottom:32}}>
          {tiers.map(([k,name,price,note])=>(
            <label key={k} onClick={()=>setTier(k)} style={{display:'flex',gap:16,alignItems:'center',cursor:'pointer',
              border:`2px solid ${tier===k?'var(--drupal-blue)':'var(--border-subtle)'}`,borderRadius:'var(--radius-lg)',
              padding:'20px 24px',background:tier===k?'var(--surface-accent-tint)':'var(--surface-card)'}}>
              <Radio name="tier" value={k} checked={tier===k} onChange={()=>setTier(k)}/>
              <div style={{flex:1}}><span style={{font:'var(--text-h4)',display:'block'}}>{name}</span>
                <span style={{font:'var(--text-body-sm)',color:'var(--text-muted)'}}>{note}</span></div>
              <span style={{font:'var(--text-h3)',color:'var(--drupal-navy)'}}>{price}</span></label>))}
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
          <Input label="First name" placeholder="Ada"/>
          <Input label="Last name" placeholder="Lovelace"/>
          <Input label="Email" placeholder="you@example.com" style={{gridColumn:'1 / -1'}}/>
          <Input label="Organization" placeholder="Acquia"/>
          <Select label="Country" placeholder="Select a country" options={['Netherlands','Germany','United Kingdom','United States','India']}/>
          <Select label="Dietary needs" placeholder="None" options={['Vegetarian','Vegan','Gluten free','Other']}/>
          <Select label="T-shirt size" placeholder="Select a size" options={['S','M','L','XL','XXL']}/>
        </div>
        <div style={{display:'flex',flexDirection:'column',gap:12,margin:'24px 0 28px'}}>
          <Checkbox label="I agree to the Code of Conduct" description="Required for all attendees." defaultChecked/>
          <Checkbox label="Add me to the DrupalCon newsletter"/>
        </div>
        <Button size="lg" iconRight="arrow-right" onClick={()=>setSent(true)}>Continue to payment</Button>
        {sent&&<div style={{position:'fixed',right:24,bottom:24,zIndex:70}}>
          <Toast tone="success" title="Registration held" message="Your spot is reserved for 30 minutes while you pay." onClose={()=>setSent(false)}/></div>}
      </div>
      <aside style={{border:'1px solid var(--border-subtle)',borderRadius:'var(--radius-lg)',padding:28,
        display:'flex',flexDirection:'column',gap:14,background:'var(--surface-card)',position:'sticky',top:96}}>
        <Badge tone="yellow">Order summary</Badge>
        <div style={{display:'flex',justifyContent:'space-between',font:'var(--text-body-md)'}}>
          <span>{tiers.find(t=>t[0]===tier)[1]} ticket</span><span>{tiers.find(t=>t[0]===tier)[2]}</span></div>
        <div style={{display:'flex',justifyContent:'space-between',font:'var(--text-body-md)',color:'var(--text-muted)'}}>
          <span>VAT (21%)</span><span>calculated at payment</span></div>
        <div style={{borderTop:'1px solid var(--border-subtle)',paddingTop:14,display:'flex',flexDirection:'column',gap:10}}>
          {['Four days of sessions and keynotes','Summits and contribution day','Expo hall and evening socials','Session recordings after the event']
            .map(i=><span key={i} style={{display:'flex',gap:10,font:'var(--text-body-sm)'}}>
              <Icon name="check" size={16} color="var(--drupal-blue)" style={{marginTop:2}}/>{i}</span>)}
        </div>
      </aside>
    </div>
  );
}

function EventFooter(){
  return (
    <footer style={{background:'var(--drupal-navy)',color:'rgba(255,255,255,.8)',marginTop:64}}>
      <div className="wrap" style={{padding:'48px 32px',display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:28}}>
        {[['Policies',['Code of Conduct','Privacy Policy','Terms of Service','Media Policy','Photo Credits']],
          ['Contact',['Contact the team','Sponsorship','Press']],
          ['Connect',['Facebook','LinkedIn','Instagram','YouTube']],
          ['Community',['Drupal.org','Community events','Groups & meetups','Slack']]].map(([h,items])=>(
          <div key={h} style={{display:'flex',flexDirection:'column',gap:8}}>
            <span style={{font:'var(--text-eyebrow)',letterSpacing:'var(--tracking-caps)',textTransform:'uppercase',color:'var(--blue-pale)'}}>{h}</span>
            {items.map(i=><a key={i} href="#" style={{font:'var(--text-body-sm)',color:'rgba(255,255,255,.82)',textDecoration:'none'}}>{i}</a>)}
          </div>))}
      </div>
      <div className="wrap" style={{padding:'0 32px 40px',font:'var(--text-body-sm)',color:'rgba(255,255,255,.6)',maxWidth:'70ch'}}>
        DrupalCon is brought to you by the Drupal Association with support from our generous sponsors and an amazing team of contributors.
      </div>
    </footer>
  );
}
Object.assign(window,{EventHeader,EventHome,ProgramPage,RegisterPage,EventFooter});

import React from 'react';
import {Icon} from '../core/Icon.jsx';
import {IconButton} from '../core/IconButton.jsx';

const TONES={
  info:{icon:'info',accent:'var(--status-info)'},
  success:{icon:'check-circle',accent:'var(--status-success)'},
  warning:{icon:'alert-triangle',accent:'var(--status-warning)'},
  danger:{icon:'alert-circle',accent:'var(--status-danger)'}
};

export function Toast({title,message,tone='info',onClose,style,...rest}){
  const t=TONES[tone]||TONES.info;
  return (
    <div role="status" {...rest} style={{display:'flex',gap:12,alignItems:'flex-start',minWidth:320,maxWidth:440,
      padding:'16px 16px 16px 18px',background:'var(--surface-card)',borderRadius:'var(--radius-md)',
      border:'1px solid var(--border-subtle)',borderLeft:`4px solid ${t.accent}`,boxShadow:'var(--shadow-md)',...style}}>
      <Icon name={t.icon} size={20} color={t.accent} style={{marginTop:2}}/>
      <div style={{display:'flex',flexDirection:'column',gap:2,flex:1}}>
        {title&&<span style={{font:'var(--text-label)',color:'var(--text-strong)'}}>{title}</span>}
        {message&&<span style={{font:'var(--text-body-sm)',color:'var(--text-body)'}}>{message}</span>}
      </div>
      {onClose&&<IconButton icon="x" label="Dismiss" size="sm" onClick={onClose}/>}
    </div>
  );
}

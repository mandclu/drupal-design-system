One-line: modal for trial signup, destructive confirmation and cookie-style decisions; navy scrim at 48% with a 3px blur.

```jsx
<Dialog open={open} title="Start your Drupal CMS trial" description="Trial sites are temporary but fully featured."
  onClose={close} footer={<><Button variant="outline" onClick={close}>Cancel</Button><Button>Create trial</Button></>} />
```

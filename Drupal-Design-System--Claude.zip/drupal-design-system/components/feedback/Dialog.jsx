import React from 'react';
import {IconButton} from '../core/IconButton.jsx';

export function Dialog({open=false,title,description,children,footer,onClose,width=560,style,...rest}){
  React.useEffect(()=>{
    if(!open) return;
    const k=e=>{if(e.key==='Escape'&&onClose)onClose()};
    window.addEventListener('keydown',k);return()=>window.removeEventListener('keydown',k);
  },[open,onClose]);
  if(!open) return null;
  return (
    <div style={{position:'fixed',inset:0,zIndex:60,display:'flex',alignItems:'center',justifyContent:'center',padding:24,
      background:'rgba(18,40,95,.48)',backdropFilter:'blur(3px)'}} onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title} onClick={e=>e.stopPropagation()} {...rest}
        style={{width:'100%',maxWidth:width,background:'var(--surface-card)',borderRadius:'var(--radius-lg)',
          boxShadow:'var(--shadow-lg)',padding:32,display:'flex',flexDirection:'column',gap:16,...style}}>
        <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',gap:16}}>
          <div style={{display:'flex',flexDirection:'column',gap:8}}>
            {title&&<h3 style={{font:'var(--text-h3)',color:'var(--text-strong)',margin:0}}>{title}</h3>}
            {description&&<p style={{margin:0,font:'var(--text-body-md)',color:'var(--text-body)'}}>{description}</p>}
          </div>
          {onClose&&<IconButton icon="x" label="Close" onClick={onClose}/>}
        </div>
        {children}
        {footer&&<div style={{display:'flex',gap:12,justifyContent:'flex-end',marginTop:8}}>{footer}</div>}
      </div>
    </div>
  );
}

import * as React from 'react';
export interface TooltipProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Short, sentence-case, no terminal period. */
  label?: string;
  children?: React.ReactNode;
  placement?: 'top' | 'bottom';
}
export declare function Tooltip(props: TooltipProps): JSX.Element;

import React from 'react';

export function Tooltip({label,children,placement='top',style,...rest}){
  const [show,setShow]=React.useState(false);
  const pos=placement==='bottom'
    ?{top:'calc(100% + 8px)',left:'50%',transform:'translateX(-50%)'}
    :{bottom:'calc(100% + 8px)',left:'50%',transform:'translateX(-50%)'};
  return (
    <span style={{position:'relative',display:'inline-flex',...style}}
      onMouseEnter={()=>setShow(true)} onMouseLeave={()=>setShow(false)}
      onFocus={()=>setShow(true)} onBlur={()=>setShow(false)} {...rest}>
      {children}
      {show&&<span role="tooltip" style={{position:'absolute',zIndex:50,whiteSpace:'nowrap',...pos,
        background:'var(--drupal-navy)',color:'var(--text-inverse)',font:'var(--text-body-sm)',
        padding:'6px 10px',borderRadius:'var(--radius-xs)',boxShadow:'var(--shadow-md)'}}>{label}</span>}
    </span>
  );
}

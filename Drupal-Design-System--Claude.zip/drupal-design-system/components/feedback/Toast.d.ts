import * as React from 'react';
export interface ToastProps extends React.HTMLAttributes<HTMLDivElement> {
  title?: string;
  message?: string;
  tone?: 'info' | 'success' | 'warning' | 'danger';
  onClose?: () => void;
}
export declare function Toast(props: ToastProps): JSX.Element;

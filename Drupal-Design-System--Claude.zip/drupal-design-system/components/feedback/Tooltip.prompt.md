One-line: navy hover/focus hint for icon-only controls; never put essential information only in a tooltip.

```jsx
<Tooltip label="Copy install command"><IconButton icon="copy" label="Copy" /></Tooltip>
```

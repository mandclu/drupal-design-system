import * as React from 'react';
export interface DialogProps extends React.HTMLAttributes<HTMLDivElement> {
  open?: boolean;
  title?: string;
  description?: string;
  children?: React.ReactNode;
  /** Right-aligned action row — pass Buttons. */
  footer?: React.ReactNode;
  /** Called on overlay click, close button and Escape. */
  onClose?: () => void;
  width?: number;
}
export declare function Dialog(props: DialogProps): JSX.Element;

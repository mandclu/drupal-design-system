One-line: transient confirmation or system message, stacked bottom-right.

```jsx
<Toast tone="success" title="Recipe applied" message="SEO tools are now installed." onClose={fn} />
```

The 4px accent edge is the one place the system uses a coloured left border — it is a status device, not a decorative one.

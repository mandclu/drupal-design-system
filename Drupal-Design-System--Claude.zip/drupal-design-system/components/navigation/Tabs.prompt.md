One-line: in-page section switcher — underline for content tabs, pill for filter rows.

```jsx
<Tabs items={['Overview','Features','Recipes','Docs']} onChange={fn} />
<Tabs variant="pill" items={['All','Modules','Themes','Recipes']} />
```

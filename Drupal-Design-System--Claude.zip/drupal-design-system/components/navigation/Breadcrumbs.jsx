import React from 'react';
import {Icon} from '../core/Icon.jsx';

export function Breadcrumbs({items=[],style,...rest}){
  return (
    <nav aria-label="Breadcrumb" {...rest} style={{display:'flex',alignItems:'center',flexWrap:'wrap',gap:8,...style}}>
      {items.map((it,i)=>{
        const label=it.label||it,href=it.href;
        const last=i===items.length-1;
        return <React.Fragment key={label}>
          {href&&!last
            ?<a href={href} style={{font:'var(--text-body-sm)',color:'var(--text-link)',textDecoration:'none'}}>{label}</a>
            :<span aria-current={last?'page':undefined} style={{font:'var(--text-body-sm)',color:last?'var(--text-strong)':'var(--text-muted)'}}>{label}</span>}
          {!last&&<Icon name="chevron-right" size={14} color="var(--neutral-400)"/>}
        </React.Fragment>;
      })}
    </nav>
  );
}

import React from 'react';

export function Tabs({items=[],value,defaultValue,onChange,variant='underline',style,...rest}){
  const [inner,setInner]=React.useState(defaultValue??(items[0]&&(items[0].value||items[0])));
  const active=value!==undefined?value:inner;
  const pick=v=>{if(value===undefined)setInner(v);onChange&&onChange(v)};
  const pill=variant==='pill';
  return (
    <div role="tablist" {...rest} style={{display:'flex',gap:pill?8:28,
      borderBottom:pill?'none':'1px solid var(--border-subtle)',...style}}>
      {items.map(it=>{
        const v=it.value||it,l=it.label||it,on=v===active;
        return <button key={v} role="tab" aria-selected={on} onClick={()=>pick(v)}
          style={{border:0,background:pill?(on?'var(--drupal-navy)':'var(--surface-subtle)'):'transparent',
            color:pill?(on?'var(--text-inverse)':'var(--drupal-navy)'):(on?'var(--drupal-navy)':'var(--text-muted)'),
            font:'var(--text-label)',padding:pill?'10px 20px':'0 0 14px',cursor:'pointer',
            borderRadius:pill?'var(--radius-pill)':0,
            boxShadow:!pill&&on?'inset 0 -3px 0 0 var(--drupal-blue)':'none',
            transition:'var(--transition-interactive)'}}>{l}</button>;
      })}
    </div>
  );
}

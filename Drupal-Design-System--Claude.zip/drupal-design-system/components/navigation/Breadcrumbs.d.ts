import * as React from 'react';
export interface Crumb { label: string; href?: string }
export interface BreadcrumbsProps extends React.HTMLAttributes<HTMLElement> {
  /** Ordered trail; the last item renders as the current page. */
  items?: Array<string | Crumb>;
}
export declare function Breadcrumbs(props: BreadcrumbsProps): JSX.Element;

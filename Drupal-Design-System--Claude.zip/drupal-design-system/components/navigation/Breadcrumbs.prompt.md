One-line: page-location trail for documentation and deep Drupal.org pages.

```jsx
<Breadcrumbs items={[{label:'Drupal.org',href:'#'},{label:'Style guide',href:'#'},{label:'Typography'}]} />
```

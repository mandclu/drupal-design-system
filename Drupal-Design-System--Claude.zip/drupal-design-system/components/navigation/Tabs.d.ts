import * as React from 'react';
export interface TabItem { value: string; label: string }
/**
 * Section switcher.
 * @startingPoint section="Navigation" subtitle="Tabs and breadcrumbs" viewport="700x200"
 */
export interface TabsProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Strings or {value,label} pairs. */
  items?: Array<string | TabItem>;
  /** Controlled active value. */
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  /** underline = in-page sections; pill = filter groups. */
  variant?: 'underline' | 'pill';
}
export declare function Tabs(props: TabsProps): JSX.Element;

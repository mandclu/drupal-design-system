import * as React from 'react';
export interface DropWindowProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The photo or video to mask - give it width/height 100 percent and objectFit cover. */
  children?: React.ReactNode;
  size?: number;
  /** Path from the consuming page to the PNG logo mirror. */
  basePath?: string;
  /** Shown where the photo doesn't cover. */
  background?: string;
}
export declare function DropWindow(props: DropWindowProps): JSX.Element;

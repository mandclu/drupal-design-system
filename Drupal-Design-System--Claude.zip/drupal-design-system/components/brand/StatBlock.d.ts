import * as React from 'react';
export interface StatBlockProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The figure, written as it should read: "400k+", "70%", "3,604". */
  value?: React.ReactNode;
  /** Sentence-case supporting line, no terminal period. */
  label?: React.ReactNode;
  tone?: 'navy' | 'blue' | 'inverse';
  align?: 'left' | 'center';
}
export declare function StatBlock(props: StatBlockProps): JSX.Element;

import * as React from 'react';
/**
 * Official Drupal / Drupal CMS marks, straight from the brand portal SVGs in assets/png/logos.
 * @startingPoint section="Brand" subtitle="Logo lockups, GUI blocks and stat figures" viewport="700x300"
 */
export interface LogoProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  /** drupal-* = the project mark; cms-* = the Drupal CMS product logo; drop = drop only. */
  variant?: 'drupal-horizontal' | 'drupal-vertical' | 'drop' | 'cms-horizontal' | 'cms-vertical' | 'cms-mark';
  /** CMS product logos exist in blue and white only; navy/black fall back to blue. */
  color?: 'blue' | 'navy' | 'white' | 'black';
  /** Rendered height in px; width follows. Never below 24px for wordmark lockups. */
  height?: number;
  /** Path from the consuming page to assets/png/logos. */
  basePath?: string;
}
export declare function Logo(props: LogoProps): JSX.Element;

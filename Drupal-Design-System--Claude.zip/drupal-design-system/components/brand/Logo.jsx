import React from 'react';

const FILES={
  'drupal-horizontal':n=>`Drupal-Logo_Horizontal_${n}.png`,
  'drupal-vertical':n=>`Drupal-Logo_Vertical_${n}.png`,
  'drop':n=>`Drupal-Drop_${n}.png`,
  'cms-horizontal':n=>`Drupal-Product-Logo-CMS-Horizontal-Wordmark-${n}.png`,
  'cms-vertical':n=>`Drupal-Product-Logo-CMS-Vertical-Wordmark-${n}.png`,
  'cms-mark':n=>`Drupal-Product-Logo-CMS-Horizontal-No-Wordmark-${n}.png`
};
const COLORS={blue:'Blue',navy:'Navy',white:'White',black:'Black'};

export function Logo({variant='drupal-horizontal',color='blue',height=40,basePath='assets/png/logos',alt,style,...rest}){
  const key=FILES[variant]?variant:'drupal-horizontal';
  let name=COLORS[color]||'Blue';
  if(key.startsWith('cms')&&(name==='Navy'||name==='Black')) name='Blue'; // CMS product logo ships blue + white only
  const src=`${basePath}/${FILES[key](name)}`;
  return <img src={src} alt={alt??(key.startsWith('cms')?'Drupal CMS':'Drupal')} {...rest}
    style={{height,width:'auto',display:'block',...style}}/>;
}

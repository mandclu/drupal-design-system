One-line: oversized proof figure in ZT Gatha with a short supporting line — used in the "Trusted by the world's biggest brands" and case-study bands.

```jsx
<StatBlock value="400k+" label="websites using Drupal today" />
<StatBlock value="70%" label="Top 100 universities use Drupal" tone="inverse" align="center" />
```

import * as React from 'react';
export interface GuiBlockProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  /** Palette colour of the fill (filled) or the line (outline). */
  tone?: 'blue' | 'dark-blue' | 'navy' | 'light-blue' | 'purple' | 'yellow' | 'red' | 'green' | 'white';
  /** Optional second colour for the stroke - keep the block to 3 colours total, white included. */
  lineColor?: string;
  /** filled = solid panel, outline = line block (the guidelines' default construction). */
  variant?: 'filled' | 'outline';
  size?: number;
  /** Defaults to 17 percent of the size, which keeps the brand's corner proportion. */
  radius?: number;
  /** 0-3 control dots. They are never filled. */
  dots?: 0 | 1 | 2 | 3;
  /** The 45 degree line shadow. Blocks don't always have to carry it. */
  lineShadow?: boolean;
  lineWidth?: number;
  /** Photo/video content, turning the block into a window or frame. */
  image?: React.ReactNode;
}
export declare function GuiBlock(props: GuiBlockProps): JSX.Element;

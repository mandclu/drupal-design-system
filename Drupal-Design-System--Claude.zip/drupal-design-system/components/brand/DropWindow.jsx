import React from 'react';

/* "Drop Window": the drop — or a rectangle cropped out of part of it — used as a mask for
   photography or video. The mask is the official white drop asset, so the silhouette is exact. */
export function DropWindow({children,size=280,basePath='assets/png/logos',
  background='var(--surface-subtle)',style,...rest}){
  const url='url("'+basePath+'/Drupal-Drop_White.png")';
  return (
    <div {...rest} style={{width:size,height:size,background,overflow:'hidden',
      WebkitMaskImage:url,maskImage:url,WebkitMaskRepeat:'no-repeat',maskRepeat:'no-repeat',
      WebkitMaskSize:'contain',maskSize:'contain',WebkitMaskPosition:'center',maskPosition:'center',...style}}>
      {children}
    </div>
  );
}

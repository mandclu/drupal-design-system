One-line: full-bleed section background using the brand's dynamic drop patterns — for hero bands, CTA bands and slide backgrounds.

```jsx
<PatternPanel pattern="blue-dense" background="var(--drupal-navy)" basePath="../../assets/png/patterns"
  style={{padding:'96px 48px'}}>
  <h2 style={{color:'var(--drupal-white)'}}>Come for the code, stay for the community</h2>
</PatternPanel>
```

One patterned band per screen. Keep text out of the busiest area, or drop opacity to ~0.35 behind copy.

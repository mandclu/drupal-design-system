One-line: the GUI Block — Drupal's signature graphic device, derived from classic operating-system windows; use it to frame imagery, hold a headline or structure a layout.

```jsx
<GuiBlock tone="yellow" size={280}>Slide Deck Template</GuiBlock>
<GuiBlock variant="outline" tone="blue" lineColor="navy" size={220} dots={0} />
<GuiBlock tone="red" size={240} dots={1} image={<img src="photo.jpg" alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/>} />
```

Rules from the guidelines:
- Construction: rounded rectangle, duplicated and shifted diagonally at 45°, offset no closer or further than **3 line widths**; matching corners share a radius.
- **0 to 3 control dots**, depending on space available, and **never filled**.
- **Maximum 3 colours per block, white included.** **Never a gradient inside a GUI Block.**
- The line shadow and the dots are both optional.
- **Frame vs window:** use it as a *frame* over a full-bleed image when the focus is one or two people, a detail of an image, or an impactful headline. Use it as a *window* when you need room for copy or several images — then pair the background colour or gradient with the theme of the headline or image.

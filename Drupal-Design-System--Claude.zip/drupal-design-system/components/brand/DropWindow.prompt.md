One-line: masks photography or video into the Drupal drop — the guidelines' "Drop Window" device, used for community portraits and hero collages.

```jsx
<DropWindow size={320} basePath="../../assets/png/logos">
  <img src="community.jpg" alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/>
</DropWindow>
```

The guidelines also allow **cropping a rectangle out of the drop** to make window shapes — size the drop up and clip it with a positioned container rather than distorting the mark. The mask is always the full drop silhouette — the inner Community Drop is only ever shown as part of an official logo file. Never stretch, rotate or recolour the drop, and never use the *full logo* (drop + wordmark) as a transparent window.

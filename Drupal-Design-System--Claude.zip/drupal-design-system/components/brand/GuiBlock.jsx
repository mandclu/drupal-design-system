import React from 'react';

const FILL={blue:'var(--drupal-blue)','dark-blue':'var(--drupal-dark-blue)',navy:'var(--drupal-navy)',
  'light-blue':'var(--drupal-light-blue)',purple:'var(--drupal-purple)',yellow:'var(--drupal-yellow)',
  red:'var(--drupal-red)',green:'var(--drupal-green)',white:'var(--drupal-white)'};
const INK_ON={blue:'var(--drupal-white)','dark-blue':'var(--drupal-white)',navy:'var(--drupal-white)',
  'light-blue':'var(--drupal-navy)',purple:'var(--drupal-navy)',yellow:'var(--drupal-navy)',
  red:'var(--drupal-white)',green:'var(--drupal-white)',white:'var(--drupal-navy)'};

/* The brand's GUI Block, built the way the guidelines describe it:
   rounded rectangle -> duplicate shifted diagonally at 45 degrees (offset kept to ~3 line
   widths) -> matching corner radii -> 0-3 unfilled control dots -> 45 degree line shadow.
   Enforced here: never more than 3 colours per block, never a gradient fill. */
export function GuiBlock({children,tone='yellow',lineColor,variant='filled',size=320,radius,
  dots=3,lineShadow=true,lineWidth=2,image,style,...rest}){
  const fill=FILL[tone]||FILL.yellow;
  const stroke=lineColor?(FILL[lineColor]||lineColor):fill;
  const r=radius??Math.round(size*0.17);
  const filled=variant==='filled';
  const ink=filled?(INK_ON[tone]||'var(--drupal-navy)'):stroke;
  const off=lineWidth*3;
  const dotCount=Math.max(0,Math.min(3,dots));
  const shadow=`repeating-linear-gradient(135deg,${filled?fill:stroke} 0 ${lineWidth}px,transparent ${lineWidth}px ${lineWidth*4}px)`;
  const shift=`translate(-${off}px,${off}px)`;
  return (
    <div {...rest} style={{position:'relative',width:size,height:size,...style}}>
      {lineShadow&&<div aria-hidden="true" style={{position:'absolute',inset:0,transform:shift,borderRadius:r,background:shadow}}/>}
      {!filled&&<div aria-hidden="true" style={{position:'absolute',inset:0,transform:shift,borderRadius:r,
        border:lineWidth+'px solid '+stroke}}/>}
      <div style={{position:'absolute',inset:0,borderRadius:r,overflow:'hidden',
        background:filled?fill:'var(--surface-page)',
        border:filled?'none':lineWidth+'px solid '+stroke,
        display:'flex',flexDirection:'column'}}>
        {image&&<div style={{position:'absolute',inset:0}}>{image}</div>}
        {dotCount>0&&<div style={{position:'relative',display:'flex',gap:Math.round(size*0.03),
          padding:Math.round(size*0.07)+'px '+Math.round(size*0.075)+'px 0'}}>
          {Array.from({length:dotCount}).map((_,i)=>
            <span key={i} style={{width:Math.round(size*0.044),height:Math.round(size*0.044),borderRadius:'50%',
              border:Math.max(2,lineWidth)+'px solid '+ink}}/>)}
        </div>}
        <div style={{position:'relative',flex:1,display:'flex',alignItems:'center',justifyContent:'center',
          padding:Math.round(size*0.075),font:'var(--text-h3)',color:ink,textAlign:'center'}}>{children}</div>
      </div>
    </div>
  );
}

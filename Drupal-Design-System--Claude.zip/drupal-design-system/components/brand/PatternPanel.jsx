import React from 'react';

const PATTERNS={
  'blue-dense':'Drupal_Dynamic-Patterns-01.png',
  'blue-multiply':'Drupal_Dynamic-Patterns-02.png',
  'tint-lines':'Drupal_Dynamic-Patterns-03.png',
  'grey-soft':'Drupal_Dynamic-Patterns-04.png',
  'lavender-mix':'Drupal_Dynamic-Patterns-05.png',
  'grey-light':'Drupal_Dynamic-Patterns-06.png'
};

export function PatternPanel({children,pattern='blue-dense',background='var(--surface-page)',size='cover',position='center',opacity=1,basePath='assets/png/patterns',style,...rest}){
  const file=PATTERNS[pattern]||PATTERNS['blue-dense'];
  return (
    <div {...rest} style={{position:'relative',isolation:'isolate',background,overflow:'hidden',...style}}>
      <div aria-hidden="true" style={{position:'absolute',inset:0,zIndex:-1,opacity,
        backgroundImage:`url("${basePath}/${file}")`,backgroundSize:size,backgroundPosition:position,backgroundRepeat:'no-repeat'}}/>
      {children}
    </div>
  );
}

import * as React from 'react';
export interface PatternPanelProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  /** One of the six brand "dynamic pattern" artworks in assets/png/patterns/. */
  pattern?: 'blue-dense' | 'blue-multiply' | 'tint-lines' | 'grey-soft' | 'lavender-mix' | 'grey-light';
  /** Base fill behind the artwork. */
  background?: string;
  /** background-size value; "cover" for full-bleed bands, a px value to tile a corner. */
  size?: string;
  position?: string;
  opacity?: number;
  /** Path from the consuming page to assets/png/patterns. */
  basePath?: string;
}
export declare function PatternPanel(props: PatternPanelProps): JSX.Element;

One-line: renders an approved Drupal or Drupal CMS lockup — never redraw or recolour the mark.

```jsx
<Logo variant="drupal-horizontal" color="navy" height={36} basePath="../../assets/png/logos" />
<Logo variant="cms-vertical" color="white" height={96} basePath="../../assets/png/logos" />
```

Rules from the brand portal: Drupal CMS is the one product logo; the "CMS"-only secondary marks (`cms-mark`) need Drupal Association permission. Keep clear space of at least the drop's width on all sides. Set `basePath` to reach `assets/png/logos` from your page.

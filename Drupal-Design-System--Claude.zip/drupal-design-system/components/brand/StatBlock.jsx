import React from 'react';

export function StatBlock({value,label,tone='navy',align='left',style,...rest}){
  const color=tone==='inverse'?'var(--drupal-white)':tone==='blue'?'var(--drupal-blue)':'var(--drupal-navy)';
  return (
    <div {...rest} style={{display:'flex',flexDirection:'column',gap:4,textAlign:align,alignItems:align==='center'?'center':'flex-start',...style}}>
      <span style={{font:'var(--text-display)',color,letterSpacing:'var(--tracking-tight)'}}>{value}</span>
      <span style={{font:'var(--text-body-md)',color:tone==='inverse'?'rgba(255,255,255,.82)':'var(--text-body)',maxWidth:'22ch'}}>{label}</span>
    </div>
  );
}

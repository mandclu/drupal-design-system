One-line: native select with brand chrome and a Lucide chevron.

```jsx
<Select label="Filter by" placeholder="All industries"
  options={['Government','Higher education','Nonprofit','Retail']} />
```

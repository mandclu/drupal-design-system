One-line: the standard text field — 48px tall, 8px radius, blue focus ring.

```jsx
<Input label="Work email" placeholder="you@example.com" hint="We only use this to send your trial link." />
<Input label="Site name" error="Enter a name to continue" />
<Input iconLeft="search" placeholder="Search Drupal.org" aria-label="Search" />
```

import React from 'react';

export function Radio({label,description,name,value,checked,onChange,disabled=false,id,style,...rest}){
  const uid=id||React.useId();
  return (
    <label htmlFor={uid} style={{display:'flex',gap:12,alignItems:'flex-start',cursor:disabled?'not-allowed':'pointer',opacity:disabled?.5:1,...style}}>
      <input id={uid} type="radio" name={name} value={value} checked={checked} disabled={disabled} onChange={onChange}
        style={{position:'absolute',opacity:0,width:0,height:0}} {...rest}/>
      <span aria-hidden="true" style={{flex:'0 0 auto',width:22,height:22,marginTop:1,borderRadius:'50%',
        display:'flex',alignItems:'center',justifyContent:'center',background:'var(--surface-page)',
        border:`2px solid ${checked?'var(--action-primary)':'var(--border-strong)'}`,transition:'var(--transition-interactive)'}}>
        {checked&&<span style={{width:11,height:11,borderRadius:'50%',background:'var(--action-primary)'}}/>}</span>
      <span style={{display:'flex',flexDirection:'column',gap:2}}>
        <span style={{font:'var(--text-body-md)',color:'var(--text-strong)'}}>{label}</span>
        {description&&<span style={{font:'var(--text-body-sm)',color:'var(--text-muted)'}}>{description}</span>}
      </span>
    </label>
  );
}

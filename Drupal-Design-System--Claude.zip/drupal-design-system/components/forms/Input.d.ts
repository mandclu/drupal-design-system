import * as React from 'react';
/**
 * Single-line text field with label, hint and error states.
 * @startingPoint section="Forms" subtitle="Text fields, selects, checkboxes, radios, switches" viewport="700x380"
 */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  /** Helper text under the field. */
  hint?: string;
  /** Replaces the hint and turns the field coral. */
  error?: string;
  /** Lucide icon slug shown inside the field, left. */
  iconLeft?: string;
}
export declare function Input(props: InputProps): JSX.Element;

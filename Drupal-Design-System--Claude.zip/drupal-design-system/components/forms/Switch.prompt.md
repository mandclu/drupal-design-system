One-line: instant-effect toggle (settings, consent, feature flags) — not for form submission choices; use Checkbox there.

```jsx
<Switch label="Allow analytics cookies" defaultChecked />
```

import React from 'react';

export function Switch({label,checked,defaultChecked,onChange,disabled=false,id,style,...rest}){
  const uid=id||React.useId();
  const [inner,setInner]=React.useState(!!defaultChecked);
  const on=checked!==undefined?checked:inner;
  return (
    <label htmlFor={uid} style={{display:'inline-flex',gap:12,alignItems:'center',cursor:disabled?'not-allowed':'pointer',opacity:disabled?.5:1,...style}}>
      <input id={uid} type="checkbox" role="switch" checked={on} disabled={disabled}
        onChange={e=>{if(checked===undefined)setInner(e.target.checked);onChange&&onChange(e)}}
        style={{position:'absolute',opacity:0,width:0,height:0}} {...rest}/>
      <span aria-hidden="true" style={{width:48,height:28,borderRadius:'var(--radius-pill)',padding:3,display:'flex',
        background:on?'var(--action-primary)':'var(--neutral-300)',transition:'background-color var(--duration-base) var(--ease-standard)'}}>
        <span style={{width:22,height:22,borderRadius:'50%',background:'var(--drupal-white)',
          transform:on?'translateX(20px)':'translateX(0)',transition:'transform var(--duration-base) var(--ease-standard)',
          boxShadow:'var(--shadow-sm)'}}/></span>
      {label&&<span style={{font:'var(--text-body-md)',color:'var(--text-strong)'}}>{label}</span>}
    </label>
  );
}

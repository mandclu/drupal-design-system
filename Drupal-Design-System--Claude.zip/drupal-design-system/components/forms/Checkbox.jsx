import React from 'react';
import {Icon} from '../core/Icon.jsx';

export function Checkbox({label,description,checked,defaultChecked,onChange,disabled=false,id,style,...rest}){
  const uid=id||React.useId();
  const [inner,setInner]=React.useState(!!defaultChecked);
  const on=checked!==undefined?checked:inner;
  return (
    <label htmlFor={uid} style={{display:'flex',gap:12,alignItems:'flex-start',cursor:disabled?'not-allowed':'pointer',opacity:disabled?.5:1,...style}}>
      <input id={uid} type="checkbox" checked={on} disabled={disabled}
        onChange={e=>{if(checked===undefined)setInner(e.target.checked);onChange&&onChange(e)}}
        style={{position:'absolute',opacity:0,width:0,height:0}} {...rest}/>
      <span aria-hidden="true" style={{flex:'0 0 auto',width:22,height:22,marginTop:1,display:'flex',alignItems:'center',justifyContent:'center',
        borderRadius:'var(--radius-xs)',background:on?'var(--action-primary)':'var(--surface-page)',
        border:`2px solid ${on?'var(--action-primary)':'var(--border-strong)'}`,
        transition:'var(--transition-interactive)'}}>
        {on&&<Icon name="check" size={14} color="var(--drupal-white)"/>}</span>
      <span style={{display:'flex',flexDirection:'column',gap:2}}>
        <span style={{font:'var(--text-body-md)',color:'var(--text-strong)'}}>{label}</span>
        {description&&<span style={{font:'var(--text-body-sm)',color:'var(--text-muted)'}}>{description}</span>}
      </span>
    </label>
  );
}

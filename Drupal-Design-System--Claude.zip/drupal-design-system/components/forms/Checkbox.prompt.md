One-line: square 4px-radius checkbox that fills Drupal blue when on; supports a description line.

```jsx
<Checkbox label="Send me Drupal news" description="Roughly one email a month." defaultChecked />
```

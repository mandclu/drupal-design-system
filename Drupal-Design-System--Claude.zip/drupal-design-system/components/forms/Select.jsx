import React from 'react';
import {Icon} from '../core/Icon.jsx';

export function Select({label,hint,error,options=[],placeholder,id,style,...rest}){
  const [focus,setFocus]=React.useState(false);
  const uid=id||React.useId();
  return (
    <div style={{display:'flex',flexDirection:'column',gap:6,width:'100%'}}>
      {label&&<label htmlFor={uid} style={{font:'var(--text-label)',color:'var(--text-strong)'}}>{label}</label>}
      <div style={{position:'relative',display:'flex',alignItems:'center'}}>
        <select id={uid} onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
          style={{width:'100%',minHeight:48,padding:'12px 44px 12px 16px',appearance:'none',
            font:'var(--text-body-md)',color:'var(--text-strong)',background:'var(--surface-page)',
            borderRadius:'var(--radius-sm)',
            border:`1px solid ${error?'var(--status-danger)':focus?'var(--border-brand)':'var(--border-strong)'}`,
            boxShadow:focus?'var(--shadow-focus)':'none',outline:'none',cursor:'pointer',...style}} {...rest}>
          {placeholder&&<option value="">{placeholder}</option>}
          {options.map(o=>{const v=typeof o==='string'?o:o.value,l=typeof o==='string'?o:o.label;
            return <option key={v} value={v}>{l}</option>;})}
        </select>
        <span style={{position:'absolute',right:16,pointerEvents:'none',display:'flex',color:'var(--drupal-navy)'}}>
          <Icon name="chevron-down" size={18}/></span>
      </div>
      {(hint||error)&&<span style={{font:'var(--text-body-sm)',color:error?'var(--status-danger)':'var(--text-muted)'}}>{error||hint}</span>}
    </div>
  );
}

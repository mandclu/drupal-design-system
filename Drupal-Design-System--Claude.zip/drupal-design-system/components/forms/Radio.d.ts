import * as React from 'react';
export interface RadioProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>,'type'> {
  label?: React.ReactNode;
  description?: React.ReactNode;
  /** Radios in one group share a name. */
  name?: string;
  value?: string;
  checked?: boolean;
  disabled?: boolean;
}
export declare function Radio(props: RadioProps): JSX.Element;

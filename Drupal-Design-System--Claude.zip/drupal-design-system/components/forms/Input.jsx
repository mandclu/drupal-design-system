import React from 'react';
import {Icon} from '../core/Icon.jsx';

export function Input({label,hint,error,iconLeft,id,style,...rest}){
  const [focus,setFocus]=React.useState(false);
  const uid=id||React.useId();
  return (
    <div style={{display:'flex',flexDirection:'column',gap:6,width:'100%'}}>
      {label&&<label htmlFor={uid} style={{font:'var(--text-label)',color:'var(--text-strong)'}}>{label}</label>}
      <div style={{position:'relative',display:'flex',alignItems:'center'}}>
        {iconLeft&&<span style={{position:'absolute',left:14,display:'flex',color:'var(--text-muted)'}}><Icon name={iconLeft} size={18}/></span>}
        <input id={uid} onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
          aria-invalid={!!error} aria-describedby={hint||error?uid+'-d':undefined}
          style={{width:'100%',minHeight:48,padding:iconLeft?'12px 16px 12px 42px':'12px 16px',
            font:'var(--text-body-md)',color:'var(--text-strong)',background:'var(--surface-page)',
            borderRadius:'var(--radius-sm)',
            border:`1px solid ${error?'var(--status-danger)':focus?'var(--border-brand)':'var(--border-strong)'}`,
            boxShadow:focus?'var(--shadow-focus)':'none',outline:'none',
            transition:'border-color var(--duration-fast) var(--ease-standard),box-shadow var(--duration-fast) var(--ease-standard)',...style}} {...rest}/>
      </div>
      {(hint||error)&&<span id={uid+'-d'} style={{font:'var(--text-body-sm)',color:error?'var(--status-danger)':'var(--text-muted)'}}>{error||hint}</span>}
    </div>
  );
}

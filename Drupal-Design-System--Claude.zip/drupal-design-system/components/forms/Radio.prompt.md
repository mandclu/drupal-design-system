One-line: single-choice control; always render two or more in a group with a shared `name`.

```jsx
<Radio name="path" value="cms" label="Drupal CMS" description="Recommended for most websites" checked onChange={fn} />
<Radio name="path" value="core" label="Drupal core" description="For developers" onChange={fn} />
```

import * as React from 'react';
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  /** Palette tone. Use brand/navy for status, yellow/coral/lavender for editorial emphasis. */
  tone?: 'brand' | 'navy' | 'yellow' | 'coral' | 'lavender' | 'tint' | 'neutral';
  /** Uppercase + wide tracking (default). Set false for sentence-case labels. */
  uppercase?: boolean;
}
export declare function Badge(props: BadgeProps): JSX.Element;

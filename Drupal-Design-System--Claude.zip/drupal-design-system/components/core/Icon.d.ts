import * as React from 'react';
export interface IconProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Lucide icon slug, e.g. "arrow-right", "search", "check" */
  name?: string;
  /** Square px size. 16 inline with body text, 20 in buttons, 24+ standalone. */
  size?: number;
  /** Any CSS color; defaults to currentColor. */
  color?: string;
}
export declare function Icon(props: IconProps): JSX.Element;

import React from 'react';

const CDN='https://unpkg.com/lucide-static@0.544.0/icons/';

/* Lucide is a documented SUBSTITUTION: the Drupal brand portal ships no icon set.
   Rendered as a CSS mask so the glyph inherits currentColor. */
export function Icon({name='circle',size=20,color='currentColor',strokeWidth,style,...rest}){
  const url=`url("${CDN}${name}.svg")`;
  return <span aria-hidden="true" {...rest} style={{display:'inline-block',flex:'0 0 auto',width:size,height:size,background:color,WebkitMaskImage:url,maskImage:url,WebkitMaskRepeat:'no-repeat',maskRepeat:'no-repeat',WebkitMaskSize:'contain',maskSize:'contain',WebkitMaskPosition:'center',maskPosition:'center',...style}}/>;
}

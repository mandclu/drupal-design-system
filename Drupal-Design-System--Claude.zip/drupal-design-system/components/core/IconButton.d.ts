import * as React from 'react';
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Lucide icon slug. */
  icon?: string;
  /** Required accessible name — the button has no visible text. */
  label: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'ghost' | 'outline' | 'solid';
  disabled?: boolean;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;

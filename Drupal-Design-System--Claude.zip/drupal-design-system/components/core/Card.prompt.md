One-line: the workhorse content card for feature grids, case studies and news teasers.

```jsx
<Card eyebrow="Case study" title="From WordPress worries to Drupal CMS confidence"
      body="An 88% performance boost in a six-week migration." href="#" linkLabel="Learn more"
      media={<img src="assets/graphics/Video.png" alt="" style={{width:'100%'}}/>} />
```

Tones: light (default), tint (pale blue, for supporting grids), navy (inverse, for closing CTAs).

import * as React from 'react';
export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  /** Filled navy state for active filters. */
  selected?: boolean;
  /** Adds a trailing remove affordance. */
  onRemove?: (e: React.MouseEvent) => void;
}
export declare function Tag(props: TagProps): JSX.Element;

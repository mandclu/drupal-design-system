import * as React from 'react';
/**
 * Primary call to action. Pill geometry, 2px border on every variant so
 * filled and outline buttons share the same box.
 * @startingPoint section="Core" subtitle="Buttons, icon buttons, badges and tags" viewport="700x260"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  /** primary = Drupal blue, secondary = navy, outline/ghost for lower emphasis, inverse on dark or photo backgrounds. */
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'inverse';
  size?: 'sm' | 'md' | 'lg';
  /** Lucide icon slug rendered before the label. */
  iconLeft?: string;
  /** Lucide icon slug rendered after the label — use "arrow-right" for forward navigation. */
  iconRight?: string;
  fullWidth?: boolean;
  disabled?: boolean;
  /** Renders an <a> instead of a <button>. */
  href?: string;
}
export declare function Button(props: ButtonProps): JSX.Element;

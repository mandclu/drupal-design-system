One-line: small pill label for release status, section eyebrows and card metadata.

```jsx
<Badge tone="yellow">Now available</Badge>
<Badge tone="navy" uppercase={false}>Drupal CMS 2.0</Badge>
```

One-line: square-tap-target circular button for toolbar, dialog-close and search affordances.

```jsx
<IconButton icon="search" label="Search" />
<IconButton icon="x" label="Close" variant="outline" />
```

Minimum 44px box at `md` for touch. `label` is mandatory.

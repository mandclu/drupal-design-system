import React from 'react';
import {Icon} from './Icon.jsx';

export function Card({children,title,eyebrow,body,media,href,linkLabel,tone='light',padding=24,style,...rest}){
  const [hover,setHover]=React.useState(false);
  const dark=tone==='navy';
  const tint=tone==='tint';
  return (
    <div {...rest} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{display:'flex',flexDirection:'column',overflow:'hidden',borderRadius:'var(--radius-lg)',
        background:dark?'var(--surface-inverse)':tint?'var(--surface-accent-tint)':'var(--surface-card)',
        border:`1px solid ${dark?'var(--border-inverse)':tint?'transparent':'var(--border-subtle)'}`,
        boxShadow:href&&hover?'var(--shadow-md)':'var(--shadow-sm)',
        transform:href&&hover?'translateY(-2px)':'none',
        transition:'box-shadow var(--duration-base) var(--ease-standard),transform var(--duration-base) var(--ease-standard)',
        ...style}}>
      {media&&<div style={{aspectRatio:'16/9',overflow:'hidden',background:'var(--neutral-100)'}}>{media}</div>}
      <div style={{display:'flex',flexDirection:'column',gap:8,padding}}>
        {eyebrow&&<span style={{font:'var(--text-eyebrow)',letterSpacing:'var(--tracking-caps)',textTransform:'uppercase',
          color:dark?'var(--blue-pale)':'var(--drupal-blue)'}}>{eyebrow}</span>}
        {title&&<h3 style={{font:'var(--text-h4)',color:dark?'var(--text-inverse)':'var(--text-strong)'}}>{title}</h3>}
        {body&&<p style={{margin:0,font:'var(--text-body-md)',color:dark?'rgba(255,255,255,.82)':'var(--text-body)'}}>{body}</p>}
        {children}
        {href&&<a href={href} style={{display:'inline-flex',alignItems:'center',gap:6,marginTop:8,
          font:'var(--text-label)',color:dark?'var(--drupal-white)':'var(--text-link)',
          textDecoration:hover?'underline':'none'}}>{linkLabel||'Learn more'}<Icon name="arrow-right" size={16}/></a>}
      </div>
    </div>
  );
}

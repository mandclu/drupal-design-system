import React from 'react';
import {Icon} from './Icon.jsx';

const SIZES={sm:{box:36,icon:18},md:{box:44,icon:20},lg:{box:52,icon:24}};

export function IconButton({icon='x',label,size='md',variant='ghost',disabled=false,style,...rest}){
  const [hover,setHover]=React.useState(false);
  const s=SIZES[size]||SIZES.md;
  const base=variant==='solid'
    ?{background:'var(--action-primary)',color:'var(--text-on-brand)',border:'2px solid var(--action-primary)'}
    :variant==='outline'
    ?{background:'transparent',color:'var(--drupal-navy)',border:'2px solid var(--border-strong)'}
    :{background:'transparent',color:'var(--drupal-navy)',border:'2px solid transparent'};
  const hov=variant==='solid'?{background:'var(--action-primary-hover)',borderColor:'var(--action-primary-hover)'}
    :{background:'var(--surface-subtle)'};
  return (
    <button type="button" aria-label={label} disabled={disabled}
      onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{width:s.box,height:s.box,display:'inline-flex',alignItems:'center',justifyContent:'center',
        borderRadius:'var(--radius-pill)',cursor:disabled?'not-allowed':'pointer',opacity:disabled?.4:1,
        transition:'var(--transition-interactive)',...base,...(hover&&!disabled?hov:null),...style}} {...rest}>
      <Icon name={icon} size={s.icon}/>
    </button>
  );
}

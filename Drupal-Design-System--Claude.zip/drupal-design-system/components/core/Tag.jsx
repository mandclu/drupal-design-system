import React from 'react';
import {Icon} from './Icon.jsx';

export function Tag({children,selected=false,onRemove,style,...rest}){
  const [hover,setHover]=React.useState(false);
  return (
    <span {...rest} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{display:'inline-flex',alignItems:'center',gap:6,padding:onRemove?'6px 8px 6px 14px':'6px 14px',
        borderRadius:'var(--radius-pill)',font:'var(--text-body-sm)',cursor:rest.onClick?'pointer':'default',
        background:selected?'var(--drupal-navy)':hover&&rest.onClick?'var(--blue-tint)':'var(--surface-page)',
        color:selected?'var(--text-inverse)':'var(--drupal-navy)',
        border:`1px solid ${selected?'var(--drupal-navy)':'var(--border-strong)'}`,
        transition:'var(--transition-interactive)',...style}}>
      {children}
      {onRemove&&<button type="button" aria-label="Remove" onClick={onRemove}
        style={{display:'inline-flex',border:0,background:'transparent',padding:2,cursor:'pointer',color:'inherit'}}>
        <Icon name="x" size={14}/></button>}
    </span>
  );
}

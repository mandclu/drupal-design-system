import * as React from 'react';
/**
 * Content card: 20px radius, hairline border, near-flat shadow. Lifts 2px on hover
 * only when it carries an href.
 * @startingPoint section="Core" subtitle="Cards, media cards and stat blocks" viewport="700x340"
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  eyebrow?: string;
  title?: string;
  body?: string;
  /** 16:9 media slot — pass an <img> or <image-slot>. */
  media?: React.ReactNode;
  /** Turns the card into a link target and shows the trailing action. */
  href?: string;
  linkLabel?: string;
  tone?: 'light' | 'tint' | 'navy';
  padding?: number;
  children?: React.ReactNode;
}
export declare function Card(props: CardProps): JSX.Element;

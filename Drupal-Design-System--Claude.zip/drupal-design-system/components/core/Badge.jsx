import React from 'react';

const TONES={
  brand:{background:'var(--surface-brand)',color:'var(--text-on-brand)'},
  navy:{background:'var(--surface-inverse)',color:'var(--text-inverse)'},
  yellow:{background:'var(--yellow)',color:'var(--drupal-navy)'},
  coral:{background:'var(--coral)',color:'var(--drupal-white)'},
  lavender:{background:'var(--lavender)',color:'var(--drupal-navy)'},
  tint:{background:'var(--blue-tint)',color:'var(--drupal-navy)'},
  neutral:{background:'var(--neutral-100)',color:'var(--text-body)'}
};

export function Badge({children,tone='brand',uppercase=true,style,...rest}){
  const t=TONES[tone]||TONES.brand;
  return <span {...rest} style={{display:'inline-flex',alignItems:'center',padding:'4px 12px',borderRadius:'var(--radius-pill)',
    font:'var(--text-eyebrow)',letterSpacing:'var(--tracking-caps)',textTransform:uppercase?'uppercase':'none',...t,...style}}>{children}</span>;
}

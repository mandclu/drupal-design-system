import React from 'react';
import {Icon} from './Icon.jsx';

const SIZES={
  sm:{padding:'8px 16px',fontSize:'var(--size-2xs)',gap:6,icon:16,minHeight:36},
  md:{padding:'12px 24px',fontSize:'var(--size-xs)',gap:8,icon:20,minHeight:48},
  lg:{padding:'16px 32px',fontSize:'var(--size-sm)',gap:10,icon:22,minHeight:56}
};
const VARIANTS={
  primary:{background:'var(--action-primary)',color:'var(--text-on-brand)',border:'2px solid var(--action-primary)'},
  secondary:{background:'var(--action-secondary)',color:'var(--text-inverse)',border:'2px solid var(--action-secondary)'},
  outline:{background:'transparent',color:'var(--drupal-navy)',border:'2px solid var(--drupal-navy)'},
  ghost:{background:'transparent',color:'var(--drupal-blue)',border:'2px solid transparent'},
  inverse:{background:'var(--drupal-white)',color:'var(--drupal-navy)',border:'2px solid var(--drupal-white)'}
};
const HOVER={
  primary:{background:'var(--action-primary-hover)',borderColor:'var(--action-primary-hover)'},
  secondary:{background:'var(--action-secondary-hover)',borderColor:'var(--action-secondary-hover)'},
  outline:{background:'var(--drupal-navy)',color:'var(--text-inverse)'},
  ghost:{background:'var(--blue-tint)'},
  inverse:{background:'var(--blue-tint)',borderColor:'var(--blue-tint)'}
};

export function Button({children,variant='primary',size='md',iconLeft,iconRight,fullWidth=false,disabled=false,as='button',href,style,...rest}){
  const [hover,setHover]=React.useState(false);
  const [press,setPress]=React.useState(false);
  const s=SIZES[size]||SIZES.md, v=VARIANTS[variant]||VARIANTS.primary;
  const Tag=href?'a':as;
  return (
    <Tag href={href} disabled={Tag==='button'?disabled:undefined} aria-disabled={disabled||undefined}
      onMouseEnter={()=>setHover(true)} onMouseLeave={()=>{setHover(false);setPress(false)}}
      onMouseDown={()=>setPress(true)} onMouseUp={()=>setPress(false)}
      style={{display:fullWidth?'flex':'inline-flex',width:fullWidth?'100%':'auto',alignItems:'center',justifyContent:'center',
        gap:s.gap,padding:s.padding,minHeight:s.minHeight,borderRadius:'var(--radius-pill)',
        fontFamily:'var(--font-body)',fontWeight:'var(--weight-semibold)',fontSize:s.fontSize,lineHeight:1,
        textDecoration:'none',cursor:disabled?'not-allowed':'pointer',opacity:disabled?.4:1,
        transition:'var(--transition-interactive)',transform:press&&!disabled?'translateY(1px)':'none',
        ...v,...(hover&&!disabled?HOVER[variant]:null),...style}} {...rest}>
      {iconLeft&&<Icon name={iconLeft} size={s.icon}/>}
      <span>{children}</span>
      {iconRight&&<Icon name={iconRight} size={s.icon}/>}
    </Tag>
  );
}

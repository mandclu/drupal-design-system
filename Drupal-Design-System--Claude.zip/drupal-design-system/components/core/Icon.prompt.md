One-line: monochrome Lucide glyph that inherits currentColor — use for every UI icon, since the Drupal brand portal supplies no icon set.

```jsx
<Icon name="arrow-right" size={20} />
<Icon name="search" size={16} color="var(--drupal-navy)" />
```

Loads from the lucide-static CDN via CSS mask, so it needs network access. Never hand-draw replacement SVGs; never use emoji as icons.

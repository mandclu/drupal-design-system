One-line: the standard Drupal CTA — pill-shaped, Noto Sans semibold; use `primary` for the single main action per view and `outline` for the secondary.

```jsx
<Button variant="primary" size="lg" iconRight="arrow-right">Try Drupal CMS</Button>
<Button variant="outline">Download & Build</Button>
```

Variants: primary (blue), secondary (navy), outline, ghost, inverse (white — for navy or photo backgrounds). Sizes sm/md/lg; `lg` for hero CTAs only. Hover darkens the fill; press nudges down 1px.

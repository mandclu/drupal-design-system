One-line: outlined pill for taxonomy, filters and facet chips — selectable and removable.

```jsx
<Tag onClick={()=>{}}>Accessibility</Tag>
<Tag selected>Drupal 11</Tag>
<Tag onRemove={()=>{}}>Higher education</Tag>
```

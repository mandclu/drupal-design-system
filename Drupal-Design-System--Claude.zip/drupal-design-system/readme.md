# Drupal Design System

An implementation of the **new Drupal brand** as a working design system: the official brand
assets, CSS tokens, React primitives, three product UI kits and a slide deck.

Namespace for consuming pages: `window.DrupalDesignSystem_e0f3ad`.

---

## 1. Context

Drupal is open source software and a global community, stewarded by the non-profit **Drupal
Association**. The brand's own framing: *"Drupal and the open web go hand in hand. The open web is
a web that's built for everyone — a free, public internet that all people around the world can
access for information, connection, commerce, and political participation."* And, plainly:
**"Drupal has a soul. It is purpose over product. An open web for everyone."**

**Brand attributes:** Flexible · Ambitious · Open · Powerful · Secure.

Two ways to build, treated as distinct audiences:

- **Drupal core** — "the open source framework behind millions of websites", for developers and expert users.
- **Drupal CMS** — "a ready-to-use platform for marketing teams, content creators and site builders", built on Drupal 11. Per the guidelines, **Drupal CMS is currently the only product offering, so the Drupal CMS logo is the primary product logo**; the "CMS"-only secondary lockups need Drupal Association permission. Drupal CMS 2.0 adds Drupal Canvas (visual page building), site templates, one-click marketing integrations and governed AI tooling.
- **Drupal AI** — a positioning theme, not a separate product logo.

Surfaces covered here: Drupal.org, the Drupal CMS marketing site, and DrupalCon / Drupal Events.
The Drupal CMS *admin* experience (Claro / Gin / Canvas) is **out of scope** — it has its own
admin design system and no assets for it were supplied.

### Sources used

| Source | Access | What came from it |
| --- | --- | --- |
| **Drupal Brand Guidelines** (Widen Brand Portal) — saved HTML + 47 page images, at `uploads/Drupal Brand Portal HTML/` | ✅ read | Every rule in sections 2–4: palette hexes/Pantones/tiers, gradient pairs, type roles, logo and clear-space rules, misuse lists, GUI Block construction, Drop Window, patterns, photography direction, presentation layouts |
| Brand-portal asset ZIPs (user export) | ✅ | Logos, product logos, GUI blocks, dynamic patterns, gradient swatches (`assets/`) |
| `ZT Gatha` webfonts + Noto Sans variable TTFs (user upload) | ✅ | `assets/fonts/` |
| Figma — `https://www.figma.com/design/tKYim76bnDZAyWubUi3sVv/New-Drupal-Brand---Drupal.org-Design?node-id=1105-5744` | ❌ **no access** — no `.fig` export available and the URL is not fetchable from here | Nothing. Drupal.org redesign layout/grid specs remain unverified |
| `new.drupal.org`, `www.drupal.org`, `events.drupal.org` | ✅ read as text | All product copy, nav structures, stats, case studies and event details in the UI kits |

Every hex in `tokens/colors.css` is the official value from the palette page; nothing was
reconstructed from memory.

---

## 2. Content fundamentals

**Voice.** Confident, plain, community-first. "We" only when speaking as the Association or
community; product copy addresses the reader as **you** ("Your launchpad…", "Your content, your
data, your choice"). Never corporate third person.

**Boilerplate.** The guidelines' standard descriptor, used under headlines in ads and posters:
*"Drupal is the open-source CMS that helps you deliver ambitious, elegant, and performant digital
experience at scale."* Standard closing CTA: *"Find out more at Drupal.org"*.

**Headline library** (real examples from the guidelines — short, declarative, often a period):
"Welcome to the open web." · "Fear No Monolith." · "Freedom is in our code." · "Precision is in our
code." · "Creativity is in our code." · "Code comes and goes. Community is forever." · "Create
Remarkable Websites that Scale." · "The Most Powerful Brands Run on Drupal." · "Drupal powers
1-in-40 websites." · "In A World of Templates, Be An Original." · "Come for the code, stay for the
community." · "Open Source. Endless Possibilities." · "Born to Be Open."

The pattern: a claim of 3–6 words, ending in a full stop, often built on "… is in our code."
Longer headline? The guidelines say **separate the image** — move to a GUI-block window layout
rather than crowding a frame.

**Casing.** Sentence case for body, UI labels and most headings; marketing headlines are often
Title Case on the live site ("Why Ambitious Marketers Choose Drupal CMS") — match the source when
recreating a page, prefer sentence case for new work. Product names are exact: *Drupal CMS*,
*Drupal core* (lowercase core), *Drupal AI*, *Drupal Canvas*, *DrupalCon*, *Druplicon*.

**Vocabulary that recurs.** "ambitious", "out-of-the-box", "smart defaults", "recipes", "site
templates", "open source" (two words), "the open web", "purpose over product".

**Numbers as proof.** Short and unqualified — "400k+", "70%", "1-in-40", "88%", "26-33% faster
performance" — with a lowercase supporting line and no terminal period.

**Buttons and CTAs.** Verb-first, 2–4 words: "Try Drupal CMS", "Download & Build", "Learn more",
"Become A Member Today", "Make a Donation", "Register now". Never "Click here".

**Emoji: no.** Nothing in the guidelines or on any Drupal.org surface uses emoji. Unicode arrows
are avoided too — use an icon glyph.

**Trademark.** "Drupal is a registered trademark of Dries Buytaert." The wordmark carries ™ in
the lockups; don't add one in running text.

---

## 3. Visual foundations

### Colour

Three tiers, named exactly as the guidelines name them:

- **Primary** — Drupal Blue `#009CDE` (Pantone 7460 C), Drupal Dark Blue `#006AA9` (363 C), Drupal Navy `#12285F` (540 C)
- **Secondary** — Drupal Light Blue `#CCEDF9` (2975 C), Black `#000000` (Black 6C), White
- **Tertiary** — Drupal Purple `#CCBAF4` (2645 C), Drupal Yellow `#FFC423` (1235 C), Drupal Red `#F46351` (Warm Red C), Drupal Green `#397618` (363 C)

"The colour palette gives options for diversity as wide as our community can be." Grey is
allowed in many applications — always pick a W3C-compliant value. Accessibility pairings are
prescribed (see the *Contrast pairings* card): e.g. on Drupal Blue only Navy or Black; on Navy,
Blue / White / Light Blue / Purple / Yellow; on Light Blue, Dark Blue / Navy / Black.

### Gradients

Six approved two-stop gradients, by tier — **Primary:** Blue→Navy, Dark Blue→Light Blue;
**Secondary:** Purple→Blue, Red→Yellow; **Tertiary:** Purple→Red, Yellow→Light Blue. No third
stop, no unapproved pairs, and **never a gradient inside a GUI Block**. Type on a gradient must
be compliant with **both** stops when the split is 50/50, and with the colour directly beneath it
when the split is uneven. Only Navy, White or Black logos may sit on a gradient.

### Typography

- **ZT Gatha** — headlines, subheads and H1 tags. **Bold (700) and Semi-Bold (600) only.** An Alt cut with alternate glyphs exists for most characters. For languages ZT Gatha doesn't support, use **Noto Sans Bold**.
- **Noto Sans** — H2 tags, eyebrows and body copy. Only bold, bold italic, medium, medium italic, regular and italic.
- **Noto Sans Bold** is also the type for all **sub-branding** ("Drupal / Second Line"), in Drupal Blue or Navy — white if the logo is white.
- The wordmark is set in ZT Gatha: **never re-key it**, always use an official file.

Headlines run tight (1.05–1.2 line-height, −0.02em tracking at display sizes); body copy
1.55–1.65 at 16–20px with measure around 60–70ch. Token roles live in `tokens/typography.css`;
the ramp itself (76 / 60 / 48 / 38 / 30 / 20px) is this system's, not a published brand scale.

### The logo and the drop

The primary logo is the **Drupal Drop + wordmark**, horizontal or stacked. The drop "represents the
fluid nature of the open web — a ripple that extends outward, creating an impact greater than its
size", and is composed of three named parts: the **Greater Drop** (classic Drupal and its impact),
the **Community Drop** (many parts forming a cohesive whole — the inner mark) and the **Individual
Drop** (a single contributor).

- Drop colours: **Drupal Blue, Navy, White or Black only.**
- Light backgrounds → Blue, Navy or Black. On Navy or Black → **only Blue or White.** All other medium/dark backgrounds → White.
- **Clear space = the width of the Individual Drop** on all four sides.
- Misuse (all explicitly forbidden): changing the drop-to-wordmark size relationship, non-brand colours, outlining, drop shadows or glows, non-proportional stretching, rotating any part, re-keying the wordmark, placing it on a busy background or image, changing its opacity, or using the full logo as a transparent window.

### The GUI Block

The signature device, drawn from operating-system windows: *"the GUI is still a vital part of
computing… Drupal's new brand has incorporated this essential computing element."* Anatomy:
**control dots**, the **GUI block** itself, and the **line shadow**.

Construction (guidelines, verbatim steps): rectangle → round the corners → duplicate and shift
diagonally at **45°**, no closer or further than **3 line widths** → round inner and outer corners
to match → add control dots and 45° shadow lines. Rules: **0–3 control dots** depending on space,
**never filled**; **maximum 3 colours per block including white**; **no gradients**; the shadow lines
and dots are optional. Line, fill and image fills are all valid.

**Frame vs window** — use the block as a *frame* over a full-bleed image when the focus is one or
two people, a specific detail, or an impactful headline. Use it as a *window* when you need room
for copy or several images; then pair the background colour or gradient with the theme of the
headline or image.

### Drop Window

Brand elements double as photography/video windows: the drop, or a rectangle cropped out of part
of the drop, becomes the image mask ("sizing up parts of the Drupal Drop to create interesting
window shapes"). Implemented as the `DropWindow` component.

### Patterns

Several approved **dynamic patterns**, "inspired by classic computing screen savers and GUI
elements", add depth: diagonal stripes, a drop lattice, fine checkerboard, clover/drop florets,
topographic swirls and wave lines. **Do not use unapproved patterns.** One patterned band per
screen; drop to ~20–45% opacity behind text.

### Photography

The four key attributes: **Warmth, Cooperation, Diversity, Friendliness.** Natural light and
realistic settings; lighting appropriate to the scene; colours expressive and bright. Photography
should represent the diverse community that contributes to Drupal — a wide range of races,
ethnicities, ages, gender expressions, sexual orientations and abilities. **Don't** use black and
white, muting, sepia, duotone, artificial colouring, HDR or any photography filter; avoid moody
studio portraits and backlit silhouettes.

This system ships **no photography** — the shots in the guideline pages are licensed stock comps.
Image areas in the kits and slides are labelled slots.

### Layout, surface and interaction (system-level, derived)

1272px max container, 32px padding, 24px gutter, 2/3/4-up card grids, 96px between bands (56px
compact), 4px spacing base. Radii 4 / 8 / 12 / 20 / 32px plus a large GUI-block radius (~17% of
the block edge) and full pill for buttons, badges and tags. Cards: white surface, 20px radius, 1px
`#E4E4E4` hairline, near-flat shadow; no coloured left-border accents except the Toast status edge.
Depth is flat — three low-contrast navy shadows only; the real brand depth device is the 45° hatch.
Transparency/blur only for the dialog scrim (navy 48%, 3px blur) and text-over-pattern.
Hover darkens filled buttons (Blue → Dark Blue; Navy → `#162C63`), fills outline buttons navy, tints
ghost buttons Light Blue; links thicken their underline; press nudges 1px; cards with a destination
lift 2px. Focus: 2px Drupal Blue outline at 2px offset, plus a `rgba(0,156,222,.4)` ring on fields.
Motion: 120ms hover, 200ms toggles, 320ms overlays, `cubic-bezier(.2,0,.2,1)`; fades and short
slides only — no springs or bounce.

### Presentations

The guidelines show a slide set built entirely from these parts: GUI-block-framed slides in white,
Blue and Navy; date top-left in the block's title bar; the logo bottom-right in a white rounded
tile; a drop watermark in the corner; bulleted lists in Noto Sans. "All typographic, GUI Block,
image and colour rules apply." See `slides/` and `templates/drupal-deck/`.

---

## 4. Iconography

- **The brand ships no icon set.** The portal contains logos, GUI blocks, patterns and gradients only; the live sites use bespoke illustrated PNG feature icons that were not exportable.
- **Substitution (flagged):** [Lucide](https://lucide.dev) `lucide-static@0.544.0`, loaded from CDN and rendered through the `Icon` component as a CSS mask so glyphs inherit `currentColor`. Its 2px outline, round-cap style is the closest match to the GUI-block line language. **If the Association has an official icon library, swap it in — `Icon` is the single seam.**
- Sizes: 16px inline, 20px in buttons, 24–36px as feature marks. Monochrome, never boxed in a coloured tile.
- The **drop** is the one brand glyph — favicon, compact header mark, corner watermark — in Blue, Navy, White or Black only.
- The **Druplicon** mascot is for community groups and events, not the software or product marketing. No Druplicon file was in the export.
- **No emoji, no unicode dingbats** as icons.

---

## 5. Index

**Root** — `styles.css` (the single entry point consumers link; `@import` list only),
`thumbnail.html`, `readme.md`, `SKILL.md`.

**`tokens/`** — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `radius-shadow.css`,
`motion.css`, `base.css`.

**`assets/`** — `logos/` (12 Drupal marks + 8 Drupal CMS lockups, SVG), `gui-blocks/` (5 SVG),
`patterns/` (6 SVG), `gradients/` (6 SVG), `graphics/` (GUI-block PNGs, "Video" and "Slide Deck
Template" blocks, the Product Logos guideline page), `fonts/` (ZT Gatha woff2 ×4, Noto Sans
variable ×2), plus a **PNG mirror at `assets/png/`** (logos, patterns, gui-blocks) — use the PNGs
in HTML `<img>`/`background-image`, since some hosts serve `.svg` with the wrong content type.
The full brand guidelines (47 pages) are kept at `uploads/Drupal Brand Portal HTML/`.

**`guidelines/`** — specimen cards: colour (primary, secondary, tertiary, working blues, semantic
aliases, gradients, contrast pairings), type (display, heading ladder, body, utility roles,
pairing), spacing (scale, layout rhythm, radii, elevation & hatch, motion), brand (logo lockups,
logo on backgrounds, clear space, drop anatomy, brand attributes, GUI blocks, patterns,
photography direction, iconography).

**`components/`** — 21 primitives:
- `core/` — **Button**, **IconButton**, **Icon**, **Badge**, **Tag**, **Card**
- `forms/` — **Input**, **Select**, **Checkbox**, **Radio**, **Switch**
- `navigation/` — **Tabs**, **Breadcrumbs**
- `feedback/` — **Dialog**, **Toast**, **Tooltip**
- `brand/` — **Logo**, **GuiBlock**, **DropWindow**, **StatBlock**, **PatternPanel**

Each has a `.d.ts` props contract and a `.prompt.md` usage note; each directory has a `@dsCard`
showcase HTML.

**`ui_kits/`** — `drupal-cms/`, `drupal-org/`, `drupalcon/` (each with its own README and fidelity notes).

**`slides/`** — eight slide types + a keyboard-navigable `index.html`.

**`templates/drupal-deck/`** — `DrupalDeck.dc.html`, the reusable 1920×1080 brand deck (title,
section break, bullets, comparison, stats, closing) with thumbnail rail, keyboard nav and
print-to-PDF. Start real presentations here; `slides/` is the specimen set.

### Intentional additions

No component library was available (Figma inaccessible, no codebase), so the primitives are the
standard set sized to Drupal's needs. Five are brand-specific: **Icon** (the seam for the
substituted icon set), **Logo** (enforces approved lockups and colours), **GuiBlock** and
**DropWindow** (the two graphic devices the guidelines define), **PatternPanel** / **StatBlock**
(the patterned band and oversized proof figure that appear on every Drupal marketing surface).
`Tooltip` and `Breadcrumbs` exist because the Drupal.org kit needs them.

---

## 6. Known gaps

1. **No Figma access** — the Drupal.org redesign's layout, grid and component specs are unverified; the UI kits are on-brand reconstructions from live copy, not pixel recreations.
2. **No brand-owned photography or illustrated feature icons** — image areas are labelled slots.
3. **No icon set** — Lucide substitution, flagged above.
4. **ZT Gatha ships Bold + Semi-Bold (plus Alt cuts) only.**
5. **Type scale, spacing scale and interaction states are this system's**, not published brand values — the guidelines cover identity, not a UI spec.
6. **Drupal CMS admin UI (Claro/Gin/Canvas) is out of scope.**
7. The guidelines reference **web brand standards** ("See the web brand standards for more") that were not in the export — worth chasing for the Drupal.org side.
